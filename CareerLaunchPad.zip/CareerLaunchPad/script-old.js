// Initialize Supabase and load pages on homepage
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize Supabase client
    const client = initSupabase();

    // Load pages from Supabase if on homepage
    const pagesGrid = document.getElementById('pages-grid');
    if (pagesGrid && client) {
        await loadPagesFromSupabase(client);
    }
});

// Load pages from Supabase
async function loadPagesFromSupabase(client) {
    const pagesGrid = document.getElementById('pages-grid');

    try {
        // Fetch all published pages
        const { data: pages, error } = await client
            .from(PAGES_TABLE)
            .select('*')
            .eq('published', true)
            .order('order_index', { ascending: true });

        if (error) {
            throw error;
        }

        // Clear loading message
        pagesGrid.innerHTML = '';

        if (!pages || pages.length === 0) {
            pagesGrid.innerHTML = `
                <div class="no-pages-message">
                    <p>No pages available yet. Add some content in the <a href="/admin.html">Admin Panel</a>!</p>
                </div>
            `;
            return;
        }

        // Create page cards
        pages.forEach(page => {
            const pageCard = createPageCard(page);
            pagesGrid.appendChild(pageCard);
        });

        // Apply animations
        applyScrollAnimations();

    } catch (error) {
        console.error('Error loading pages:', error);
        pagesGrid.innerHTML = `
            <div class="error-message">
                <p>Failed to load pages. Please check your Supabase configuration in config.js</p>
            </div>
        `;
    }
}

// Create a page card element
function createPageCard(page) {
    const card = document.createElement('a');
    card.href = `page.html?page=${page.slug}`;
    card.className = 'page-card';

    card.innerHTML = `
        <div class="page-thumbnail">
            <div class="page-icon">${page.icon || '📄'}</div>
            <h3>${page.title}</h3>
        </div>
        <div class="page-description">
            <p>${page.description || 'Click to read more'}</p>
        </div>
    `;

    return card;
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Form submission handler
const contactForm = document.querySelector('.contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // Get form values
        const formData = new FormData(this);

        // Show success message (you can customize this)
        alert('Thank you for your message! We will get back to you soon.');

        // Reset form
        this.reset();

        // Here you can add actual form submission logic:
        // - Send to a backend API
        // - Use a service like Formspree, EmailJS, etc.
        // - Integrate with Vercel serverless functions
    });
}

// Add active state to navigation links based on scroll position
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-links a');

    let current = '';

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (pageYOffset >= sectionTop - 100) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// Add animation on scroll (optional enhancement)
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Apply scroll animations to cards
function applyScrollAnimations() {
    document.querySelectorAll('.resource-card, .page-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
}

// Apply animations to existing cards on page load
applyScrollAnimations();

// Newsletter form handler
const newsletterForm = document.querySelector('.newsletter-form');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for subscribing! You will receive our newsletter soon.');
        this.reset();
    });
}
