-- ============================================
-- PROGRESS TRACKING SYSTEM - SETUP
-- ============================================
-- Run this in your Supabase SQL Editor to enable
-- user progress tracking, streaks, points, and rankings
-- ============================================

-- 1. USER STATS TABLE
-- ============================================
-- Stores aggregate stats for each user

CREATE TABLE IF NOT EXISTS user_stats (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    total_points INT DEFAULT 0,
    topics_completed INT DEFAULT 0,
    last_activity_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. USER PROGRESS TABLE
-- ============================================
-- Tracks which pages each user has viewed/completed

CREATE TABLE IF NOT EXISTS user_progress (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    page_id UUID REFERENCES pages(id) ON DELETE CASCADE,
    completed BOOLEAN DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    last_visited TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, page_id)
);

-- 3. USER ACTIVITY LOG TABLE
-- ============================================
-- Logs all user activities for timeline/history

CREATE TABLE IF NOT EXISTS user_activity (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    activity_type TEXT NOT NULL, -- 'page_view', 'page_complete', 'video_watch', 'login'
    page_id UUID REFERENCES pages(id) ON DELETE SET NULL,
    points_earned INT DEFAULT 0,
    metadata JSONB, -- Store additional data like video_id, time_spent, etc.
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. CREATE INDEXES FOR PERFORMANCE
-- ============================================

CREATE INDEX IF NOT EXISTS idx_user_progress_user ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_user_progress_page ON user_progress(page_id);
CREATE INDEX IF NOT EXISTS idx_user_progress_completed ON user_progress(user_id, completed);

CREATE INDEX IF NOT EXISTS idx_user_activity_user ON user_activity(user_id);
CREATE INDEX IF NOT EXISTS idx_user_activity_type ON user_activity(activity_type);
CREATE INDEX IF NOT EXISTS idx_user_activity_date ON user_activity(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_stats_points ON user_stats(total_points DESC);
CREATE INDEX IF NOT EXISTS idx_user_stats_streak ON user_stats(current_streak DESC);

-- 5. ENABLE ROW LEVEL SECURITY
-- ============================================

ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;

-- 6. CREATE RLS POLICIES
-- ============================================

-- User Stats Policies
CREATE POLICY "Users can view own stats"
ON user_stats FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update own stats"
ON user_stats FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own stats"
ON user_stats FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- User Progress Policies
CREATE POLICY "Users can view own progress"
ON user_progress FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own progress"
ON user_progress FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
ON user_progress FOR UPDATE
USING (auth.uid() = user_id);

-- User Activity Policies
CREATE POLICY "Users can view own activity"
ON user_activity FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activity"
ON user_activity FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Admins can view all stats (for leaderboard, analytics)
CREATE POLICY "Authenticated users can view all stats for leaderboard"
ON user_stats FOR SELECT
USING (auth.role() = 'authenticated');

-- 7. CREATE AUTO-UPDATE TRIGGER
-- ============================================

DROP TRIGGER IF EXISTS update_user_stats_updated_at ON user_stats;
CREATE TRIGGER update_user_stats_updated_at
    BEFORE UPDATE ON user_stats
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 8. HELPER FUNCTION: CALCULATE USER RANK
-- ============================================

CREATE OR REPLACE FUNCTION get_user_rank(p_user_id UUID)
RETURNS INT AS $$
DECLARE
    user_rank INT;
BEGIN
    SELECT rank INTO user_rank
    FROM (
        SELECT user_id, RANK() OVER (ORDER BY total_points DESC, current_streak DESC) as rank
        FROM user_stats
    ) ranked
    WHERE user_id = p_user_id;

    RETURN COALESCE(user_rank, 0);
END;
$$ LANGUAGE plpgsql;

-- 9. HELPER FUNCTION: GET LEADERBOARD
-- ============================================

CREATE OR REPLACE FUNCTION get_leaderboard(limit_count INT DEFAULT 10)
RETURNS TABLE (
    rank BIGINT,
    user_id UUID,
    user_email TEXT,
    user_name TEXT,
    total_points INT,
    current_streak INT,
    topics_completed INT
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        ROW_NUMBER() OVER (ORDER BY us.total_points DESC, us.current_streak DESC) as rank,
        us.user_id,
        au.email as user_email,
        au.raw_user_meta_data->>'full_name' as user_name,
        us.total_points,
        us.current_streak,
        us.topics_completed
    FROM user_stats us
    JOIN auth.users au ON au.id = us.user_id
    ORDER BY us.total_points DESC, us.current_streak DESC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 10. HELPER FUNCTION: UPDATE STREAK
-- ============================================

CREATE OR REPLACE FUNCTION update_user_streak(p_user_id UUID)
RETURNS VOID AS $$
DECLARE
    today DATE := CURRENT_DATE;
    last_activity DATE;
    new_streak INT;
BEGIN
    -- Get last activity date
    SELECT last_activity_date INTO last_activity
    FROM user_stats
    WHERE user_id = p_user_id;

    -- Calculate new streak
    IF last_activity IS NULL THEN
        -- First activity ever
        new_streak := 1;
    ELSIF last_activity = today THEN
        -- Already active today, don't change streak
        RETURN;
    ELSIF last_activity = today - 1 THEN
        -- Active yesterday, increment streak
        SELECT current_streak + 1 INTO new_streak
        FROM user_stats
        WHERE user_id = p_user_id;
    ELSE
        -- Streak broken, reset to 1
        new_streak := 1;
    END IF;

    -- Update user_stats
    UPDATE user_stats
    SET
        current_streak = new_streak,
        longest_streak = GREATEST(longest_streak, new_streak),
        last_activity_date = today,
        updated_at = NOW()
    WHERE user_id = p_user_id;

    -- If user doesn't have stats yet, create them
    IF NOT FOUND THEN
        INSERT INTO user_stats (user_id, current_streak, longest_streak, last_activity_date)
        VALUES (p_user_id, 1, 1, today);
    END IF;
END;
$$ LANGUAGE plpgsql;

-- 11. SAMPLE DATA (Optional - for testing)
-- ============================================

-- Uncomment to insert sample stats for your user
-- Replace 'YOUR_USER_ID' with actual UUID from auth.users

/*
INSERT INTO user_stats (user_id, current_streak, longest_streak, total_points, topics_completed)
VALUES (
    'YOUR_USER_ID',
    5,
    10,
    150,
    12
)
ON CONFLICT (user_id) DO NOTHING;
*/

-- ============================================
-- Setup Complete! ✅
-- ============================================
-- Next steps:
-- 1. Update page.html with "Mark as Complete" button
-- 2. Update dashboard.html to load real stats
-- 3. Test by completing some pages
-- ============================================
