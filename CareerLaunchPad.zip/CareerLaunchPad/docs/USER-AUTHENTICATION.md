# User Authentication Guide

## Current Setup vs User Accounts

Your Career LaunchPad currently has **admin-only authentication**. Here's what this means and your options for regular users.

---

## 🔐 Current Setup (Admin Only)

### What You Have Now

✅ **Admin Authentication**
- Only admins can login via `/login.html`
- Protected admin panel at `/admin.html`
- Regular users browse content without logging in

✅ **Public Content Access**
- Anyone can visit your site
- Anyone can view all published pages
- No login required to read content
- Search and filter work for everyone

### When This Works Well

This setup is perfect for:
- 📚 **Educational blogs** - Share knowledge freely
- 🎓 **Learning resources** - Public access to tutorials
- 📖 **Documentation sites** - Open knowledge base
- 🌐 **Portfolio sites** - Showcase your work

**Current user flow:**
```
Regular User:
1. Visit homepage
2. Browse/search content
3. Read pages
4. No login needed ✅

Admin:
1. Visit /login.html
2. Enter credentials
3. Access /admin.html
4. Manage content
```

---

## 👥 Adding User Accounts (Optional)

If you want regular users to create accounts, here are your options:

### Option 1: Simple User Registration (Recommended)

**Use Case:** Track who's using your site, personalize experience

**Implementation Steps:**

#### 1. Create a Signup Page

Create `signup.html`:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Career LaunchPad</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h1>Create Account</h1>
            <form id="signup-form">
                <input type="email" id="email" placeholder="Email" required>
                <input type="password" id="password" placeholder="Password (min 6 chars)" required>
                <input type="text" id="full-name" placeholder="Full Name" required>
                <button type="submit">Sign Up</button>
            </form>
            <p>Already have an account? <a href="login-user.html">Login</a></p>
        </div>
    </div>

    <script src="config.js"></script>
    <script>
        const client = initSupabase();

        document.getElementById('signup-form').addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const fullName = document.getElementById('full-name').value;

            try {
                const { data, error } = await client.auth.signUp({
                    email: email,
                    password: password,
                    options: {
                        data: {
                            full_name: fullName
                        }
                    }
                });

                if (error) throw error;

                alert('Account created! Check your email to verify.');
                window.location.href = 'login-user.html';
            } catch (error) {
                alert('Error: ' + error.message);
            }
        });
    </script>
</body>
</html>
```

#### 2. Create User Login Page

Create `login-user.html`:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Career LaunchPad</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h1>User Login</h1>
            <form id="login-form">
                <input type="email" id="email" placeholder="Email" required>
                <input type="password" id="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <p>Don't have an account? <a href="signup.html">Sign Up</a></p>
            <p><a href="/">Back to Home</a></p>
        </div>
    </div>

    <script src="config.js"></script>
    <script>
        const client = initSupabase();

        document.getElementById('login-form').addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            try {
                const { data, error } = await client.auth.signInWithPassword({
                    email: email,
                    password: password
                });

                if (error) throw error;

                // Redirect to user dashboard
                window.location.href = 'dashboard.html';
            } catch (error) {
                alert('Login failed: ' + error.message);
            }
        });
    </script>
</body>
</html>
```

#### 3. Create User Dashboard

Create `dashboard.html`:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Dashboard - Career LaunchPad</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <h1 class="logo"><a href="/">Career LaunchPad</a></h1>
                <ul class="nav-links">
                    <li><a href="/">Home</a></li>
                    <li><a href="dashboard.html" class="active">Dashboard</a></li>
                    <li><a href="#" id="logout-btn">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <div class="container">
            <h1>Welcome, <span id="user-name"></span>!</h1>
            <p>Email: <span id="user-email"></span></p>

            <h2>Your Activity</h2>
            <!-- Add personalized content here -->
            <p>This is where you can show user-specific data like:</p>
            <ul>
                <li>Pages they've bookmarked</li>
                <li>Progress tracking</li>
                <li>Recently viewed pages</li>
                <li>Completed tutorials</li>
            </ul>
        </div>
    </main>

    <script src="config.js"></script>
    <script>
        const client = initSupabase();

        async function checkAuth() {
            const { data: { session } } = await client.auth.getSession();

            if (!session) {
                window.location.href = 'login-user.html';
                return;
            }

            // Display user info
            document.getElementById('user-name').textContent =
                session.user.user_metadata.full_name || 'User';
            document.getElementById('user-email').textContent =
                session.user.email;
        }

        document.getElementById('logout-btn').addEventListener('click', async (e) => {
            e.preventDefault();
            await client.auth.signOut();
            window.location.href = '/';
        });

        checkAuth();
    </script>
</body>
</html>
```

#### 4. Update Index.html Navigation

Add login/signup buttons to your homepage:

```html
<!-- In index.html navbar -->
<ul class="nav-links">
    <li><a href="/">Home</a></li>
    <li><a href="signup.html">Sign Up</a></li>
    <li><a href="login-user.html">Login</a></li>
</ul>

<!-- Or show based on auth state -->
<ul class="nav-links" id="nav-links">
    <!-- Populated by JavaScript -->
</ul>

<script>
async function updateNav() {
    const { data: { session } } = await client.auth.getSession();
    const nav = document.getElementById('nav-links');

    if (session) {
        nav.innerHTML = `
            <li><a href="/">Home</a></li>
            <li><a href="dashboard.html">Dashboard</a></li>
            <li><a href="#" id="nav-logout">Logout</a></li>
        `;
        document.getElementById('nav-logout').addEventListener('click', async () => {
            await client.auth.signOut();
            location.reload();
        });
    } else {
        nav.innerHTML = `
            <li><a href="/">Home</a></li>
            <li><a href="signup.html">Sign Up</a></li>
            <li><a href="login-user.html">Login</a></li>
        `;
    }
}

updateNav();
</script>
```

---

### Option 2: Social Login (Easy for Users)

Add Google, GitHub, or other social login options.

#### Enable in Supabase

1. **Supabase Dashboard**
   - Authentication → Providers
   - Enable Google/GitHub/etc.
   - Add OAuth credentials

2. **Update signup.html**

```javascript
// Add social login buttons
async function loginWithGoogle() {
    const { data, error } = await client.auth.signInWithOAuth({
        provider: 'google',
        options: {
            redirectTo: 'https://your-domain.com/dashboard.html'
        }
    });
}

async function loginWithGithub() {
    const { data, error } = await client.auth.signInWithOAuth({
        provider: 'github',
        options: {
            redirectTo: 'https://your-domain.com/dashboard.html'
        }
    });
}
```

```html
<!-- Add buttons to signup.html -->
<button onclick="loginWithGoogle()">Continue with Google</button>
<button onclick="loginWithGithub()">Continue with GitHub</button>
```

---

### Option 3: Magic Link Login (No Password)

Users login via email link (like Slack/Notion).

```javascript
// In login-user.html
async function sendMagicLink(email) {
    const { data, error } = await client.auth.signInWithOtp({
        email: email,
        options: {
            emailRedirectTo: 'https://your-domain.com/dashboard.html'
        }
    });

    if (!error) {
        alert('Check your email for the login link!');
    }
}
```

---

## 🎯 Feature Ideas for User Accounts

Once you have user authentication, you can add:

### 1. **Progress Tracking**

```sql
-- Create user_progress table
CREATE TABLE user_progress (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    page_id UUID REFERENCES pages(id),
    completed BOOLEAN DEFAULT false,
    completed_at TIMESTAMP,
    UNIQUE(user_id, page_id)
);
```

### 2. **Bookmarks**

```sql
-- Create bookmarks table
CREATE TABLE bookmarks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    page_id UUID REFERENCES pages(id),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, page_id)
);
```

### 3. **User Notes**

```sql
-- Create notes table
CREATE TABLE user_notes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    page_id UUID REFERENCES pages(id),
    content TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

### 4. **Comments/Discussion**

```sql
-- Create comments table
CREATE TABLE comments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    page_id UUID REFERENCES pages(id),
    content TEXT NOT NULL,
    parent_id UUID REFERENCES comments(id),
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 🔒 Important Security Considerations

### RLS Policies for User Tables

```sql
-- Users can only see their own progress
CREATE POLICY "Users can view own progress"
ON user_progress FOR SELECT
USING (auth.uid() = user_id);

-- Users can only update their own progress
CREATE POLICY "Users can update own progress"
ON user_progress FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Same for bookmarks, notes, etc.
```

### Email Verification

Enable in Supabase:
- Authentication → Settings
- Enable "Confirm email"
- Users must verify email before login

### Password Requirements

Configure in Supabase:
- Minimum length: 6-8 characters
- Complexity requirements (optional)
- Password reset flow

---

## 📊 Comparison: Admin-Only vs User Accounts

| Feature | Admin-Only (Current) | With User Accounts |
|---------|---------------------|-------------------|
| Content Access | ✅ Public | ✅ Public or restricted |
| Admin Panel | ✅ Protected | ✅ Protected |
| User Dashboard | ❌ N/A | ✅ Personalized |
| Progress Tracking | ❌ No | ✅ Yes |
| Bookmarks | ❌ No | ✅ Yes |
| Comments | ❌ No | ✅ Yes |
| Email Notifications | ❌ No | ✅ Yes |
| Complexity | ✅ Simple | ⚠️ More complex |
| Maintenance | ✅ Low | ⚠️ Higher |

---

## 🤔 Should You Add User Accounts?

### Keep Admin-Only If:
- ✅ Your content is educational and should be freely accessible
- ✅ You want to minimize complexity
- ✅ You don't need to track individual users
- ✅ You're starting small and testing the concept

### Add User Accounts If:
- ✅ You want to track user progress
- ✅ You plan to add personalized features
- ✅ You want to build a community (comments, forums)
- ✅ You need analytics on user behavior
- ✅ You want to send email notifications
- ✅ You plan to monetize (premium content, subscriptions)

---

## 🚀 Quick Implementation Steps

If you decide to add user accounts:

1. **Week 1: Basic Auth**
   - Create signup.html
   - Create login-user.html
   - Create dashboard.html
   - Test signup/login flow

2. **Week 2: User Features**
   - Add progress tracking table
   - Add bookmark functionality
   - Update UI to show login state

3. **Week 3: Polish**
   - Add email verification
   - Add password reset
   - Add social login (optional)

4. **Week 4: Advanced Features**
   - Add comments
   - Add user profiles
   - Add notifications

---

## 💡 Recommended Approach

**For now (MVP):**
1. ✅ Keep the current admin-only setup
2. ✅ Focus on creating great content
3. ✅ Test with users and get feedback

**Later (if needed):**
1. Add simple user registration
2. Add progress tracking
3. Add bookmarks
4. Add comments/community features

This way you:
- Launch quickly with current setup
- Validate your content is valuable
- Add complexity only when needed
- Have a working product to build on

---

## 📚 Resources

- [Supabase Auth Documentation](https://supabase.com/docs/guides/auth)
- [Email Templates](https://supabase.com/docs/guides/auth/auth-email-templates)
- [Social Login Setup](https://supabase.com/docs/guides/auth/social-login)
- [Row Level Security](https://supabase.com/docs/guides/auth/row-level-security)

---

**Questions?**
- Current setup works great for learning platforms
- User accounts add complexity but enable personalization
- Start simple, add features based on user feedback

---

*Last updated: 2025-01-15*
