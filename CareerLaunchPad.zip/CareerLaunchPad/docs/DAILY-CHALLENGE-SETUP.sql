-- ============================================
-- DAILY CHALLENGE SYSTEM - SETUP
-- ============================================
-- Creates daily rotating challenges with bonus points
-- Run this in your Supabase SQL Editor
-- ============================================

-- 1. CREATE DAILY CHALLENGES TABLE
-- ============================================
-- Stores available challenges that can be selected

CREATE TABLE IF NOT EXISTS daily_challenges (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    difficulty TEXT NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
    category TEXT,
    problem_statement TEXT NOT NULL,
    hints TEXT[], -- Array of progressive hints
    solution_approach TEXT,
    bonus_points INT DEFAULT 20,
    time_limit_minutes INT DEFAULT 45, -- Optional time limit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true
);

-- 2. CREATE DAILY CHALLENGE SCHEDULE TABLE
-- ============================================
-- Maps which challenge is active on which date

CREATE TABLE IF NOT EXISTS daily_challenge_schedule (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    challenge_date DATE NOT NULL UNIQUE,
    challenge_id UUID NOT NULL REFERENCES daily_challenges(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. CREATE DAILY CHALLENGE COMPLETIONS TABLE
-- ============================================
-- Tracks which users completed which daily challenges

CREATE TABLE IF NOT EXISTS daily_challenge_completions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    challenge_id UUID REFERENCES daily_challenges(id) ON DELETE CASCADE,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    time_taken_minutes INT, -- How long it took to complete
    UNIQUE(user_id, challenge_id)
);

-- 4. CREATE INDEXES
-- ============================================

CREATE INDEX IF NOT EXISTS idx_daily_challenge_schedule_date ON daily_challenge_schedule(challenge_date DESC);
CREATE INDEX IF NOT EXISTS idx_daily_challenge_completions_user ON daily_challenge_completions(user_id);
CREATE INDEX IF NOT EXISTS idx_daily_challenge_completions_challenge ON daily_challenge_completions(challenge_id);
CREATE INDEX IF NOT EXISTS idx_daily_challenge_completions_date ON daily_challenge_completions(completed_at DESC);

-- 5. ENABLE ROW LEVEL SECURITY
-- ============================================

ALTER TABLE daily_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_challenge_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_challenge_completions ENABLE ROW LEVEL SECURITY;

-- 6. CREATE RLS POLICIES
-- ============================================

-- Anyone can view active challenges
CREATE POLICY "Anyone can view active challenges"
ON daily_challenges FOR SELECT
USING (is_active = true);

-- Anyone can view challenge schedule
CREATE POLICY "Anyone can view challenge schedule"
ON daily_challenge_schedule FOR SELECT
USING (true);

-- Users can view own completions
CREATE POLICY "Users can view own completions"
ON daily_challenge_completions FOR SELECT
USING (auth.uid() = user_id);

-- Users can insert own completions
CREATE POLICY "Users can insert own completions"
ON daily_challenge_completions FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Authenticated users can view all completions (for leaderboard)
CREATE POLICY "Authenticated users can view all completions"
ON daily_challenge_completions FOR SELECT
USING (auth.role() = 'authenticated');

-- Admins can manage challenges
CREATE POLICY "Admins can manage challenges"
ON daily_challenges FOR ALL
USING (auth.role() = 'authenticated');

CREATE POLICY "Admins can manage schedule"
ON daily_challenge_schedule FOR ALL
USING (auth.role() = 'authenticated');

-- 7. FUNCTION: GET TODAY'S CHALLENGE
-- ============================================

CREATE OR REPLACE FUNCTION get_todays_challenge()
RETURNS TABLE (
    challenge_id UUID,
    title TEXT,
    description TEXT,
    difficulty TEXT,
    category TEXT,
    problem_statement TEXT,
    hints TEXT[],
    bonus_points INT,
    time_limit_minutes INT
) AS $$
DECLARE
    today DATE := CURRENT_DATE;
    v_challenge_id UUID;
BEGIN
    -- Check if there's a scheduled challenge for today
    SELECT dcs.challenge_id INTO v_challenge_id
    FROM daily_challenge_schedule dcs
    WHERE dcs.challenge_date = today;

    -- If no challenge scheduled for today, pick a random one
    IF v_challenge_id IS NULL THEN
        -- Select a random challenge that hasn't been used recently
        SELECT dc.id INTO v_challenge_id
        FROM daily_challenges dc
        WHERE dc.is_active = true
        AND dc.id NOT IN (
            SELECT challenge_id
            FROM daily_challenge_schedule
            WHERE challenge_date >= today - INTERVAL '30 days'
        )
        ORDER BY RANDOM()
        LIMIT 1;

        -- If still no challenge found, just pick any active one
        IF v_challenge_id IS NULL THEN
            SELECT dc.id INTO v_challenge_id
            FROM daily_challenges dc
            WHERE dc.is_active = true
            ORDER BY RANDOM()
            LIMIT 1;
        END IF;

        -- Schedule this challenge for today
        IF v_challenge_id IS NOT NULL THEN
            INSERT INTO daily_challenge_schedule (challenge_date, challenge_id)
            VALUES (today, v_challenge_id)
            ON CONFLICT (challenge_date) DO NOTHING;
        END IF;
    END IF;

    -- Return the challenge details
    RETURN QUERY
    SELECT
        dc.id,
        dc.title,
        dc.description,
        dc.difficulty,
        dc.category,
        dc.problem_statement,
        dc.hints,
        dc.bonus_points,
        dc.time_limit_minutes
    FROM daily_challenges dc
    WHERE dc.id = v_challenge_id;
END;
$$ LANGUAGE plpgsql;

-- 8. FUNCTION: GET TODAY'S LEADERBOARD
-- ============================================

CREATE OR REPLACE FUNCTION get_todays_leaderboard(limit_count INT DEFAULT 10)
RETURNS TABLE (
    rank BIGINT,
    user_id UUID,
    user_email TEXT,
    user_name TEXT,
    completed_at TIMESTAMP WITH TIME ZONE,
    time_taken_minutes INT
) AS $$
DECLARE
    today_challenge_id UUID;
BEGIN
    -- Get today's challenge ID
    SELECT challenge_id INTO today_challenge_id
    FROM daily_challenge_schedule
    WHERE challenge_date = CURRENT_DATE;

    IF today_challenge_id IS NULL THEN
        RETURN;
    END IF;

    -- Return leaderboard for today's challenge
    RETURN QUERY
    SELECT
        ROW_NUMBER() OVER (ORDER BY dcc.completed_at ASC) as rank,
        dcc.user_id,
        au.email as user_email,
        au.raw_user_meta_data->>'full_name' as user_name,
        dcc.completed_at,
        dcc.time_taken_minutes
    FROM daily_challenge_completions dcc
    JOIN auth.users au ON au.id = dcc.user_id
    WHERE dcc.challenge_id = today_challenge_id
    ORDER BY dcc.completed_at ASC
    LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. FUNCTION: CHECK IF USER COMPLETED TODAY'S CHALLENGE
-- ============================================

CREATE OR REPLACE FUNCTION has_completed_todays_challenge(p_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    today_challenge_id UUID;
    completion_count INT;
BEGIN
    -- Get today's challenge ID
    SELECT challenge_id INTO today_challenge_id
    FROM daily_challenge_schedule
    WHERE challenge_date = CURRENT_DATE;

    IF today_challenge_id IS NULL THEN
        RETURN false;
    END IF;

    -- Check if user completed it
    SELECT COUNT(*) INTO completion_count
    FROM daily_challenge_completions
    WHERE user_id = p_user_id
    AND challenge_id = today_challenge_id;

    RETURN completion_count > 0;
END;
$$ LANGUAGE plpgsql;

-- 10. SAMPLE DAILY CHALLENGES
-- ============================================
-- Insert some starter challenges

INSERT INTO daily_challenges (title, description, difficulty, category, problem_statement, hints, bonus_points, time_limit_minutes)
VALUES
(
    'Two Sum',
    'Find two numbers that add up to a target',
    'easy',
    'Array',
    'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

Example:
Input: nums = [2,7,11,15], target = 9
Output: [0,1]
Explanation: Because nums[0] + nums[1] == 9, we return [0, 1].

Constraints:
- Each input has exactly one solution
- You may not use the same element twice',
    ARRAY[
        'Think about using a hash map to store numbers you''ve seen',
        'For each number, check if (target - number) exists in the hash map',
        'Store the number and its index as you iterate'
    ],
    20,
    30
),
(
    'Valid Parentheses',
    'Check if brackets are balanced',
    'easy',
    'Stack',
    'Given a string s containing just the characters ''('', '')'', ''{'', ''}'', ''['' and '']'', determine if the input string is valid.

An input string is valid if:
1. Open brackets must be closed by the same type of brackets
2. Open brackets must be closed in the correct order

Example 1:
Input: s = "()"
Output: true

Example 2:
Input: s = "()[]{}"
Output: true

Example 3:
Input: s = "(]"
Output: false',
    ARRAY[
        'Use a stack data structure',
        'Push opening brackets onto the stack',
        'When you see a closing bracket, check if it matches the top of the stack',
        'At the end, the stack should be empty'
    ],
    20,
    30
),
(
    'Merge Two Sorted Lists',
    'Merge two sorted linked lists into one',
    'easy',
    'Linked List',
    'You are given the heads of two sorted linked lists list1 and list2. Merge the two lists into one sorted list.

Example:
Input: list1 = [1,2,4], list2 = [1,3,4]
Output: [1,1,2,3,4,4]

Return the head of the merged linked list.',
    ARRAY[
        'Use a dummy node to simplify the logic',
        'Compare the values of both lists and pick the smaller one',
        'Move the pointer of the list you picked from',
        'Continue until one list is exhausted, then append the remaining'
    ],
    20,
    35
),
(
    'Maximum Subarray',
    'Find the contiguous subarray with the largest sum',
    'medium',
    'Array',
    'Given an integer array nums, find the contiguous subarray (containing at least one number) which has the largest sum and return its sum.

Example:
Input: nums = [-2,1,-3,4,-1,2,1,-5,4]
Output: 6
Explanation: [4,-1,2,1] has the largest sum = 6.

Follow up: If you have figured out the O(n) solution, try coding another solution using the divide and conquer approach.',
    ARRAY[
        'This is the classic Kadane''s Algorithm problem',
        'Keep track of the current sum and maximum sum seen so far',
        'If current sum becomes negative, reset it to 0',
        'Update maximum sum whenever current sum exceeds it'
    ],
    30,
    40
),
(
    'Climbing Stairs',
    'Count distinct ways to climb n stairs',
    'easy',
    'Dynamic Programming',
    'You are climbing a staircase. It takes n steps to reach the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?

Example 1:
Input: n = 2
Output: 2
Explanation:
1. 1 step + 1 step
2. 2 steps

Example 2:
Input: n = 3
Output: 3
Explanation:
1. 1 step + 1 step + 1 step
2. 1 step + 2 steps
3. 2 steps + 1 step',
    ARRAY[
        'This is a Fibonacci sequence problem',
        'Think: to reach step n, you can come from step (n-1) or (n-2)',
        'So ways(n) = ways(n-1) + ways(n-2)',
        'Base cases: ways(1) = 1, ways(2) = 2'
    ],
    20,
    25
);

-- 11. SCHEDULE NEXT 7 DAYS (Optional)
-- ============================================
-- Uncomment to pre-schedule challenges

/*
DO $$
DECLARE
    challenge_ids UUID[];
    i INT;
BEGIN
    -- Get array of challenge IDs
    SELECT ARRAY_AGG(id) INTO challenge_ids
    FROM daily_challenges
    WHERE is_active = true
    LIMIT 7;

    -- Schedule one challenge per day for next 7 days
    FOR i IN 0..6 LOOP
        INSERT INTO daily_challenge_schedule (challenge_date, challenge_id)
        VALUES (
            CURRENT_DATE + i,
            challenge_ids[(i % array_length(challenge_ids, 1)) + 1]
        )
        ON CONFLICT (challenge_date) DO NOTHING;
    END LOOP;
END $$;
*/

-- ============================================
-- Setup Complete! ✅
-- ============================================
-- Next steps:
-- 1. Create daily-challenge.html page
-- 2. Add link to navigation
-- 3. Test completing a challenge
-- ============================================
