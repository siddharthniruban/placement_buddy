# Admin Challenges Panel Setup Guide

This guide will help you set up the comprehensive admin panel for managing daily coding challenges.

## Overview

The admin challenges panel provides:
- **CRUD Operations**: Create, Read, Update, Delete challenges
- **Scheduling Calendar**: Schedule challenges for specific dates
- **Analytics Dashboard**: View completion rates and performance metrics
- **Bulk Operations**: Import/Export challenges, bulk activate/deactivate/delete
- **Preview Mode**: Preview challenges as students see them

## Prerequisites

Before using the admin panel, ensure you have:
1. Completed the Daily Challenge setup (see `DAILY-CHALLENGE-SETUP.sql`)
2. Supabase project is configured
3. Admin email added to the admin list

## Database Setup

### Create Analytics RPC Function

To enable the full analytics dashboard, you need to create an RPC (Remote Procedure Call) function in Supabase. This function aggregates challenge performance data.

**Steps:**

1. Go to your Supabase project dashboard
2. Navigate to **SQL Editor**
3. Click **New Query**
4. Copy and paste the following SQL code:

```sql
-- Create analytics function for challenge statistics
CREATE OR REPLACE FUNCTION get_challenge_analytics()
RETURNS TABLE (
  challenge_id UUID,
  challenge_title TEXT,
  difficulty TEXT,
  category TEXT,
  total_scheduled BIGINT,
  total_completions BIGINT,
  completion_rate NUMERIC,
  avg_time_minutes NUMERIC,
  unique_users BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    dc.id as challenge_id,
    dc.title as challenge_title,
    dc.difficulty,
    dc.category,
    COUNT(DISTINCT dcs.id) as total_scheduled,
    COUNT(dcc.id) as total_completions,
    CASE
      WHEN COUNT(DISTINCT dcs.id) > 0
      THEN ROUND((COUNT(dcc.id)::NUMERIC / COUNT(DISTINCT dcs.id) * 100), 2)
      ELSE 0
    END as completion_rate,
    ROUND(AVG(dcc.time_taken_minutes)::NUMERIC, 2) as avg_time_minutes,
    COUNT(DISTINCT dcc.user_id) as unique_users
  FROM daily_challenges dc
  LEFT JOIN daily_challenge_schedule dcs ON dc.id = dcs.challenge_id
  LEFT JOIN daily_challenge_completions dcc ON dc.id = dcc.challenge_id
  WHERE dc.is_active = true
  GROUP BY dc.id, dc.title, dc.difficulty, dc.category
  ORDER BY total_completions DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

5. Click **Run** to execute the query
6. Verify the function was created successfully

**Note:** If you don't create this function, the analytics tab will still work but will show limited data with a message to create the function.

## Access Control

### Adding Admin Users

The admin panel uses email-based authentication. To add an admin user:

1. Open `dashboard.html` in your code editor
2. Find the `ADMIN_EMAILS` array (around line 320)
3. Add the admin user's email address:

```javascript
const ADMIN_EMAILS = [
    'your-admin-email@example.com',
    'another-admin@example.com'  // Add more as needed
];
```

4. Save the file

**Important:** Only users with emails in this array will see the "Admin Panel" link in the dashboard.

## Using the Admin Panel

### Accessing the Panel

1. Log in to your account
2. If you're an admin, you'll see an "Admin Panel" link in the navigation
3. Navigate to **Challenges** from the admin navigation menu

### Tab 1: Manage Challenges

#### Creating a New Challenge

1. Fill in the required fields:
   - **Title**: Name of the challenge (e.g., "Two Sum")
   - **Description**: Brief one-liner summary
   - **Difficulty**: Easy, Medium, or Hard
   - **Problem Statement**: Full problem description with examples

2. Optional fields:
   - **Category**: Topic category (e.g., Array, DP, Tree)
   - **Hints**: Click "Add Hint" to add progressive hints
   - **Solution Approach**: Guidance on solving the problem
   - **Bonus Points**: Points awarded (default: 20)
   - **Time Limit**: Suggested time in minutes (default: 45)
   - **Active**: Check to make it available for scheduling

3. Click **Save Challenge**

#### Editing a Challenge

1. Find the challenge in the list
2. Click **Edit**
3. Make your changes
4. Click **Save Challenge**

#### Other Operations

- **Delete**: Permanently remove a challenge (with confirmation)
- **Activate/Deactivate**: Toggle whether challenge can be scheduled
- **Preview**: See how the challenge appears to students
- **Duplicate**: Create a copy of the challenge

#### Search and Filter

Use the search and filter bar to find challenges:
- **Search**: Type to search by title or description
- **Difficulty Filter**: Filter by Easy, Medium, or Hard
- **Category Filter**: Filter by category
- **Active Only**: Show only active challenges

### Tab 2: Schedule

The scheduling calendar allows you to schedule challenges for specific dates.

#### Scheduling a Challenge

1. Navigate to the **Schedule** tab
2. Click on any empty date in the calendar
3. Select a challenge from the dropdown (only active challenges appear)
4. Click **Schedule**

**Note:** You can only schedule one challenge per date.

#### Unscheduling a Challenge

1. Click on a date that has a scheduled challenge
2. Review the challenge details
3. Click **Unschedule**

#### Calendar Navigation

- Use **Previous** and **Next** buttons to navigate months
- **Today** is highlighted with a blue border
- **Scheduled dates** have a green background
- **Past dates** are dimmed

### Tab 3: Analytics

The analytics dashboard shows performance metrics for all challenges.

#### Summary Stats

Four cards at the top show:
- **Total Challenges**: All challenges in the system
- **Active Challenges**: Challenges available for scheduling
- **Avg Completion Rate**: Average completion rate across all challenges
- **Total Completions**: Total number of challenge completions

#### Performance Table

The table shows detailed analytics for each challenge:
- **Challenge**: Name and difficulty
- **Category**: Topic category
- **Times Scheduled**: How many times it's been scheduled
- **Completions**: Number of times users completed it
- **Rate (%)**: Completion rate percentage
- **Avg Time (min)**: Average time taken to complete

**Note:** Requires the `get_challenge_analytics()` RPC function to be created.

### Tab 4: Bulk Actions

#### Exporting Challenges

1. Navigate to the **Bulk Actions** tab
2. Click **Export All Challenges (JSON)**
3. A JSON file will download with all your challenges

**Use cases:**
- Backup your challenges
- Share challenges with other instances
- Edit challenges in bulk using a text editor

#### Importing Challenges

1. Prepare a JSON file with challenges (use export as template)
2. Navigate to the **Bulk Actions** tab
3. Click **Choose JSON File to Import**
4. Select your JSON file
5. Review the confirmation message
6. Click **OK** to import

**Required fields in JSON:**
- `title`
- `description`
- `difficulty` (easy, medium, or hard)
- `problem_statement`

**Optional fields:**
- `category`
- `hints` (array of strings)
- `solution_approach`
- `bonus_points`
- `time_limit_minutes`
- `is_active`

#### Bulk Operations on Challenges

To perform bulk operations:

1. Go to the **Manage Challenges** tab
2. Use checkboxes to select multiple challenges
3. Or click **Select All** to select all visible challenges
4. Click one of the bulk action buttons:
   - **✅ Activate**: Activate all selected challenges
   - **❌ Deactivate**: Deactivate all selected challenges
   - **🗑️ Delete**: Delete all selected challenges (with confirmation)
5. Click **Clear Selection** to deselect all

**Warning:** Bulk delete is permanent and cannot be undone. Always export before deleting.

## Example JSON Format

Here's an example of a challenge in JSON format for import/export:

```json
[
  {
    "title": "Two Sum",
    "description": "Find two numbers in an array that add up to a target",
    "difficulty": "easy",
    "category": "Array",
    "problem_statement": "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.\n\nYou may assume that each input would have exactly one solution, and you may not use the same element twice.\n\nExample 1:\nInput: nums = [2,7,11,15], target = 9\nOutput: [0,1]\nExplanation: Because nums[0] + nums[1] == 9, we return [0, 1].",
    "hints": [
      "Try using a hash map to store the numbers you've seen",
      "For each number, check if target - number exists in the hash map"
    ],
    "solution_approach": "Use a hash map to store numbers as you iterate. For each number, check if (target - number) exists in the map. This gives O(n) time complexity.",
    "bonus_points": 20,
    "time_limit_minutes": 45,
    "is_active": true
  }
]
```

## Best Practices

### Challenge Creation

1. **Clear Problem Statements**: Use examples and explain edge cases
2. **Progressive Hints**: Order hints from general to specific
3. **Realistic Time Limits**: Base on average student solve time
4. **Consistent Categories**: Use standard categories (Array, String, DP, Tree, etc.)
5. **Test Preview**: Always preview before scheduling

### Scheduling

1. **Plan Ahead**: Schedule challenges at least a week in advance
2. **Difficulty Progression**: Alternate between easy and medium/hard
3. **Category Variety**: Don't schedule the same category consecutively
4. **Monitor Analytics**: Adjust difficulty based on completion rates

### Maintenance

1. **Regular Backups**: Export challenges weekly
2. **Review Analytics**: Check completion rates monthly
3. **Update Challenges**: Improve low-performing challenges
4. **Archive Old Challenges**: Deactivate unused challenges instead of deleting

## Troubleshooting

### Analytics Not Showing

**Problem:** Analytics tab shows "Please create the RPC function"

**Solution:**
1. Go to Supabase SQL Editor
2. Run the `get_challenge_analytics()` function creation script
3. Refresh the admin panel

### Can't Schedule Challenge

**Problem:** "A challenge is already scheduled for this date"

**Solution:**
1. Unschedule the existing challenge first
2. Or choose a different date

### Import Fails

**Problem:** "Invalid challenge format" error

**Solution:**
1. Verify your JSON file is valid JSON (use a JSON validator)
2. Check that all required fields are present:
   - title
   - description
   - difficulty
   - problem_statement
3. Ensure difficulty is one of: easy, medium, hard

### Challenge Not Appearing

**Problem:** Challenge doesn't appear in dropdown for scheduling

**Solution:**
1. Check if challenge is marked as **Active**
2. Click **Edit** and check the "Active" checkbox
3. Save the challenge

## Security Notes

1. **Admin Access**: Only users with emails in `ADMIN_EMAILS` can access admin features
2. **Row Level Security**: Ensure RLS policies are enabled in Supabase
3. **Backup Regularly**: Export challenges regularly to prevent data loss
4. **No Sensitive Data**: Don't include sensitive information in challenges

## Additional Resources

- Daily Challenge Setup: `DAILY-CHALLENGE-SETUP.sql`
- Daily Challenge Guide: `DAILY-CHALLENGE-GUIDE.md`
- Progress Tracking: `PROGRESS-TRACKING-README.md`
- User Login Setup: `USER-LOGIN-SETUP.md`

## Support

If you encounter issues:
1. Check browser console for errors
2. Verify Supabase connection
3. Review RLS policies in Supabase
4. Check that all required tables exist

## Feature Checklist

Use this checklist to verify your admin panel is working:

- [ ] Can access admin panel via navigation
- [ ] Can create new challenges
- [ ] Can edit existing challenges
- [ ] Can delete challenges (with confirmation)
- [ ] Can toggle active/inactive status
- [ ] Search and filters work
- [ ] Can schedule challenges on calendar
- [ ] Can unschedule challenges
- [ ] Analytics dashboard loads (with RPC function)
- [ ] Can export challenges as JSON
- [ ] Can import challenges from JSON
- [ ] Bulk operations work (activate, deactivate, delete)
- [ ] Preview modal shows challenges correctly
- [ ] Hints display properly in preview
- [ ] Mobile responsive (test on phone)

## Changelog

### Version 1.0 (Initial Release)
- Complete CRUD operations for challenges
- Calendar-based scheduling system
- Analytics dashboard with RPC function
- Bulk import/export functionality
- Preview mode for challenges
- Mobile-responsive design
- Search and filter capabilities
- Bulk operations (activate, deactivate, delete)
