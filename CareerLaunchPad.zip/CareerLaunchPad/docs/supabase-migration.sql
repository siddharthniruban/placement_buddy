-- Add category and difficulty columns to pages table
ALTER TABLE pages
ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'other',
ADD COLUMN IF NOT EXISTS difficulty TEXT;

-- Create index for faster filtering
CREATE INDEX IF NOT EXISTS idx_pages_category ON pages(category);

-- Update existing pages to have default category
UPDATE pages SET category = 'other' WHERE category IS NULL;
