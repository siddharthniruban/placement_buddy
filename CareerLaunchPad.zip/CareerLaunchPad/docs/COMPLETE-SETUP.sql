-- ============================================
-- Career LaunchPad - Complete Database Setup
-- ============================================
-- Run this SQL in your Supabase SQL Editor
-- This will create everything you need from scratch
-- ============================================

-- 1. CREATE PAGES TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS pages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    html_content TEXT NOT NULL,
    icon TEXT DEFAULT '📄',
    category TEXT DEFAULT 'other',
    difficulty TEXT,
    order_index INTEGER DEFAULT 0,
    published BOOLEAN DEFAULT true,
    views INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. CREATE INDEXES FOR PERFORMANCE
-- ============================================

CREATE INDEX IF NOT EXISTS idx_pages_slug ON pages(slug);
CREATE INDEX IF NOT EXISTS idx_pages_published ON pages(published);
CREATE INDEX IF NOT EXISTS idx_pages_category ON pages(category);
CREATE INDEX IF NOT EXISTS idx_pages_order ON pages(order_index);

-- 3. ENABLE ROW LEVEL SECURITY (RLS)
-- ============================================

ALTER TABLE pages ENABLE ROW LEVEL SECURITY;

-- 4. CREATE RLS POLICIES
-- ============================================

-- Policy: Anyone can view published pages
CREATE POLICY "Public pages are viewable by everyone"
ON pages FOR SELECT
USING (published = true);

-- Policy: Authenticated users (admins) can do everything
CREATE POLICY "Authenticated users can do everything"
ON pages FOR ALL
USING (auth.role() = 'authenticated');

-- 5. CREATE SAMPLE CONTENT (OPTIONAL)
-- ============================================
-- Remove or modify these if you want to start fresh

INSERT INTO pages (title, slug, icon, category, difficulty, description, html_content, order_index, published)
VALUES
(
    'Welcome to Career LaunchPad',
    'welcome',
    '👋',
    'interview',
    'Easy',
    'Get started with your journey to acing technical interviews',
    '<section class="page-hero">
        <div class="container">
            <h1>Welcome to Career LaunchPad! 👋</h1>
            <p>Your journey to mastering data structures and algorithms starts here</p>
        </div>
    </section>

    <section class="content-section">
        <div class="container">
            <div class="content-wrapper">
                <h2>What is Career LaunchPad?</h2>
                <p>Career LaunchPad is your comprehensive resource for preparing for technical interviews. We cover everything from basic data structures to advanced algorithms.</p>

                <h2>What You''ll Find Here</h2>
                <ul>
                    <li><strong>Data Structures:</strong> Arrays, Linked Lists, Trees, Graphs, and more</li>
                    <li><strong>Algorithms:</strong> Sorting, Searching, Dynamic Programming</li>
                    <li><strong>Interview Tips:</strong> How to approach technical interviews</li>
                    <li><strong>Practice Problems:</strong> Hands-on coding challenges</li>
                    <li><strong>Aptitude Tests:</strong> Improve your problem-solving skills</li>
                </ul>

                <h2>How to Use This Site</h2>
                <p>Use the search bar and category filters on the homepage to find exactly what you need. Each resource is tagged by category and difficulty level.</p>

                <p><strong>Happy Learning! 🚀</strong></p>
            </div>
        </div>
    </section>',
    1,
    true
),
(
    'Array Fundamentals',
    'array-basics',
    '📊',
    'array',
    'Easy',
    'Learn the basics of arrays and common operations',
    '<section class="page-hero">
        <div class="container">
            <h1>Array Fundamentals 📊</h1>
            <p>Master the most fundamental data structure</p>
        </div>
    </section>

    <section class="content-section">
        <div class="container">
            <div class="content-wrapper">
                <h2>What is an Array?</h2>
                <p>An array is a collection of elements stored at contiguous memory locations. It''s one of the simplest and most widely used data structures.</p>

                <h2>Key Characteristics</h2>
                <ul>
                    <li>Fixed size (in most languages)</li>
                    <li>Elements accessed by index (0-based)</li>
                    <li>O(1) access time</li>
                    <li>Contiguous memory allocation</li>
                </ul>

                <h2>Common Operations</h2>
                <ul>
                    <li><strong>Access:</strong> arr[i] - O(1)</li>
                    <li><strong>Search:</strong> Linear search - O(n)</li>
                    <li><strong>Insert:</strong> At end - O(1), elsewhere - O(n)</li>
                    <li><strong>Delete:</strong> O(n)</li>
                </ul>

                <h2>Example: JavaScript</h2>
                <pre><code>// Create an array
let numbers = [1, 2, 3, 4, 5];

// Access element
console.log(numbers[0]); // 1

// Modify element
numbers[2] = 10;

// Add element
numbers.push(6);

// Remove last element
numbers.pop();

// Iterate
numbers.forEach(num => console.log(num));
</code></pre>

                <h2>Practice Problems</h2>
                <ul>
                    <li>Find the largest element in an array</li>
                    <li>Reverse an array in place</li>
                    <li>Find duplicates in an array</li>
                    <li>Merge two sorted arrays</li>
                </ul>
            </div>
        </div>
    </section>',
    2,
    true
),
(
    'Interview Preparation Guide',
    'interview-guide',
    '💼',
    'interview',
    'Medium',
    'Essential tips and strategies for technical interviews',
    '<section class="page-hero">
        <div class="container">
            <h1>Interview Preparation Guide 💼</h1>
            <p>Ace your next technical interview with confidence</p>
        </div>
    </section>

    <section class="content-section">
        <div class="container">
            <div class="content-wrapper">
                <h2>Before the Interview</h2>
                <ul>
                    <li><strong>Research the company:</strong> Understand their products, culture, and tech stack</li>
                    <li><strong>Practice coding:</strong> Use platforms like LeetCode, HackerRank</li>
                    <li><strong>Review fundamentals:</strong> Data structures, algorithms, time complexity</li>
                    <li><strong>Prepare questions:</strong> Have thoughtful questions ready</li>
                </ul>

                <h2>During the Interview</h2>
                <ul>
                    <li><strong>Think out loud:</strong> Explain your thought process</li>
                    <li><strong>Ask clarifying questions:</strong> Understand the problem fully</li>
                    <li><strong>Start with brute force:</strong> Then optimize</li>
                    <li><strong>Test your code:</strong> Walk through examples</li>
                    <li><strong>Handle edge cases:</strong> Empty inputs, null values, etc.</li>
                </ul>

                <h2>Common Interview Patterns</h2>
                <ul>
                    <li>Two Pointers</li>
                    <li>Sliding Window</li>
                    <li>Fast & Slow Pointers</li>
                    <li>Binary Search</li>
                    <li>BFS/DFS</li>
                    <li>Dynamic Programming</li>
                </ul>

                <h2>Red Flags to Avoid</h2>
                <ul>
                    <li>❌ Jumping into code immediately</li>
                    <li>❌ Not testing your solution</li>
                    <li>❌ Giving up too quickly</li>
                    <li>❌ Ignoring hints from interviewer</li>
                    <li>❌ Not discussing time/space complexity</li>
                </ul>

                <h2>After the Interview</h2>
                <ul>
                    <li>Send a thank you email within 24 hours</li>
                    <li>Reflect on what went well and what didn''t</li>
                    <li>Follow up if you don''t hear back in a week</li>
                </ul>

                <p><strong>Remember:</strong> Interviews are a two-way street. You''re also evaluating if the company is right for you!</p>
            </div>
        </div>
    </section>',
    3,
    true
);

-- 6. CREATE AUTO-UPDATE TRIGGER (OPTIONAL)
-- ============================================
-- Automatically update updated_at timestamp

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_pages_updated_at
    BEFORE UPDATE ON pages
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Setup Complete! ✅
-- ============================================
-- Next steps:
-- 1. Go to Authentication → Users → Add User
-- 2. Create your admin account
-- 3. Visit /login.html to test authentication
-- 4. Start adding your own content!
-- ============================================
