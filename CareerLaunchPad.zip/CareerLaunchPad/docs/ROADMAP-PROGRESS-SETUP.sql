-- ============================================
-- Roadmap Progress Tracking Setup
-- ============================================
-- This script creates tables and functions for tracking user progress
-- through the 4-year college roadmap

-- Create roadmap_progress table
CREATE TABLE IF NOT EXISTS roadmap_progress (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    topic_id TEXT NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    -- Ensure one entry per user per topic
    UNIQUE(user_id, topic_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_roadmap_progress_user_id ON roadmap_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_roadmap_progress_topic_id ON roadmap_progress(topic_id);
CREATE INDEX IF NOT EXISTS idx_roadmap_progress_completed_at ON roadmap_progress(completed_at);

-- Enable Row Level Security
ALTER TABLE roadmap_progress ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own progress" ON roadmap_progress;
DROP POLICY IF EXISTS "Users can insert own progress" ON roadmap_progress;
DROP POLICY IF EXISTS "Users can update own progress" ON roadmap_progress;
DROP POLICY IF EXISTS "Users can delete own progress" ON roadmap_progress;

-- Create RLS policies
-- Users can view their own progress
CREATE POLICY "Users can view own progress" ON roadmap_progress
    FOR SELECT
    USING (auth.uid() = user_id);

-- Users can insert their own progress
CREATE POLICY "Users can insert own progress" ON roadmap_progress
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- Users can update their own progress
CREATE POLICY "Users can update own progress" ON roadmap_progress
    FOR UPDATE
    USING (auth.uid() = user_id);

-- Users can delete their own progress
CREATE POLICY "Users can delete own progress" ON roadmap_progress
    FOR DELETE
    USING (auth.uid() = user_id);

-- ============================================
-- Helper Functions
-- ============================================

-- Function to get user's roadmap progress statistics
CREATE OR REPLACE FUNCTION get_roadmap_stats(p_user_id UUID)
RETURNS TABLE (
    total_completed BIGINT,
    year1_completed BIGINT,
    year2_completed BIGINT,
    year3_completed BIGINT,
    year4_completed BIGINT,
    completion_percentage NUMERIC
) AS $$
DECLARE
    v_total_topics INTEGER := 32; -- Total topics in roadmap (update if topics change)
BEGIN
    RETURN QUERY
    SELECT
        COUNT(*)::BIGINT as total_completed,
        COUNT(*) FILTER (WHERE topic_id LIKE 'aptitude%' OR topic_id LIKE 'logical%' OR topic_id LIKE 'verbal%' OR topic_id LIKE 'programming-basics%' OR topic_id LIKE 'advanced-aptitude%' OR topic_id LIKE 'coding-pattern%' OR topic_id LIKE 'basic-ds%' OR topic_id LIKE 'git-basics%')::BIGINT as year1_completed,
        COUNT(*) FILTER (WHERE topic_id LIKE 'dsa-basics%' OR topic_id LIKE 'searching%' OR topic_id LIKE 'linked-lists%' OR topic_id LIKE 'web-basics%' OR topic_id LIKE 'stacks%' OR topic_id LIKE 'trees-basics%' OR topic_id LIKE 'oops%' OR topic_id LIKE 'first-project%')::BIGINT as year2_completed,
        COUNT(*) FILTER (WHERE topic_id LIKE 'graphs%' OR topic_id LIKE 'dynamic%' OR topic_id LIKE 'databases%' OR topic_id LIKE 'internship-prep%' OR topic_id LIKE 'heaps%' OR topic_id LIKE 'backtracking%' OR topic_id LIKE 'internship%' OR topic_id LIKE 'major-project%')::BIGINT as year3_completed,
        COUNT(*) FILTER (WHERE topic_id LIKE 'advanced-dsa%' OR topic_id LIKE 'system-design%' OR topic_id LIKE 'company-prep%' OR topic_id LIKE 'mock%' OR topic_id LIKE 'final%' OR topic_id LIKE 'behavioral%' OR topic_id LIKE 'placement%' OR topic_id LIKE 'job-offer%')::BIGINT as year4_completed,
        ROUND((COUNT(*)::NUMERIC / v_total_topics * 100), 2) as completion_percentage
    FROM roadmap_progress
    WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get recent roadmap activity
CREATE OR REPLACE FUNCTION get_recent_roadmap_activity(p_user_id UUID, p_limit INT DEFAULT 10)
RETURNS TABLE (
    topic_id TEXT,
    completed_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        rp.topic_id,
        rp.completed_at
    FROM roadmap_progress rp
    WHERE rp.user_id = p_user_id
    ORDER BY rp.completed_at DESC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to mark topic as complete (upsert)
CREATE OR REPLACE FUNCTION mark_topic_complete(p_user_id UUID, p_topic_id TEXT)
RETURNS VOID AS $$
BEGIN
    INSERT INTO roadmap_progress (user_id, topic_id, completed_at)
    VALUES (p_user_id, p_topic_id, NOW())
    ON CONFLICT (user_id, topic_id)
    DO UPDATE SET completed_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get roadmap completion by year
CREATE OR REPLACE FUNCTION get_year_wise_completion(p_user_id UUID)
RETURNS TABLE (
    year_number INTEGER,
    year_name TEXT,
    total_topics INTEGER,
    completed_topics BIGINT,
    completion_percentage NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    WITH year_topics AS (
        SELECT 1 as year, 'Year 1' as name, 8 as total UNION ALL
        SELECT 2, 'Year 2', 8 UNION ALL
        SELECT 3, 'Year 3', 8 UNION ALL
        SELECT 4, 'Year 4', 8
    ),
    year_completion AS (
        SELECT
            CASE
                WHEN topic_id IN ('aptitude-basics', 'logical-reasoning', 'verbal-ability', 'programming-basics', 'advanced-aptitude', 'coding-pattern', 'basic-ds', 'git-basics') THEN 1
                WHEN topic_id IN ('dsa-basics', 'searching-sorting', 'linked-lists', 'web-basics', 'stacks-queues', 'trees-basics', 'oops', 'first-project') THEN 2
                WHEN topic_id IN ('graphs', 'dynamic-programming', 'databases', 'internship-prep', 'heaps-hashing', 'backtracking', 'internship', 'major-project') THEN 3
                WHEN topic_id IN ('advanced-dsa', 'system-design', 'company-prep', 'mock-interviews', 'final-revision', 'behavioral', 'placement-season', 'job-offer') THEN 4
            END as year,
            COUNT(*) as completed
        FROM roadmap_progress
        WHERE user_id = p_user_id
        GROUP BY 1
    )
    SELECT
        yt.year as year_number,
        yt.name as year_name,
        yt.total as total_topics,
        COALESCE(yc.completed, 0) as completed_topics,
        ROUND((COALESCE(yc.completed, 0)::NUMERIC / yt.total * 100), 2) as completion_percentage
    FROM year_topics yt
    LEFT JOIN year_completion yc ON yt.year = yc.year
    ORDER BY yt.year;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- Sample Data (Optional - for testing)
-- ============================================
-- Uncomment below to insert sample progress for testing
-- Replace 'YOUR_USER_ID' with actual user UUID

/*
INSERT INTO roadmap_progress (user_id, topic_id, completed_at) VALUES
    ('YOUR_USER_ID', 'aptitude-basics', NOW() - INTERVAL '10 days'),
    ('YOUR_USER_ID', 'logical-reasoning', NOW() - INTERVAL '9 days'),
    ('YOUR_USER_ID', 'verbal-ability', NOW() - INTERVAL '8 days'),
    ('YOUR_USER_ID', 'programming-basics', NOW() - INTERVAL '7 days')
ON CONFLICT (user_id, topic_id) DO NOTHING;
*/

-- ============================================
-- Verification Queries
-- ============================================
-- Run these queries to verify the setup

-- Check if table exists
SELECT EXISTS (
    SELECT FROM information_schema.tables
    WHERE table_schema = 'public'
    AND table_name = 'roadmap_progress'
);

-- Check RLS is enabled
SELECT tablename, rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
AND tablename = 'roadmap_progress';

-- Check policies exist
SELECT policyname, cmd, qual
FROM pg_policies
WHERE tablename = 'roadmap_progress';

-- ============================================
-- Usage Examples
-- ============================================

-- Example 1: Get user's progress statistics
-- SELECT * FROM get_roadmap_stats('YOUR_USER_ID');

-- Example 2: Get recent activity
-- SELECT * FROM get_recent_roadmap_activity('YOUR_USER_ID', 5);

-- Example 3: Mark topic as complete
-- SELECT mark_topic_complete('YOUR_USER_ID', 'aptitude-basics');

-- Example 4: Get year-wise completion
-- SELECT * FROM get_year_wise_completion('YOUR_USER_ID');

-- ============================================
-- Notes
-- ============================================
-- 1. Update v_total_topics in get_roadmap_stats() if you add/remove topics
-- 2. The topic_id should match the IDs used in college-roadmap.html
-- 3. RLS ensures users can only see and modify their own progress
-- 4. Use upsert pattern to avoid duplicate entries
-- 5. completed_at timestamp is updated each time topic is marked complete

-- ============================================
-- Maintenance
-- ============================================

-- To reset a user's progress (use with caution):
-- DELETE FROM roadmap_progress WHERE user_id = 'YOUR_USER_ID';

-- To see all users' progress count:
-- SELECT user_id, COUNT(*) as topics_completed
-- FROM roadmap_progress
-- GROUP BY user_id
-- ORDER BY topics_completed DESC;

-- To find most popular topics:
-- SELECT topic_id, COUNT(*) as completion_count
-- FROM roadmap_progress
-- GROUP BY topic_id
-- ORDER BY completion_count DESC
-- LIMIT 10;
