# Authentication Setup Guide

This guide will help you set up admin authentication for your Career LaunchPad site.

## Prerequisites

- Supabase account and project
- Existing `pages` table in your database

## Step 1: Enable Email Authentication in Supabase

1. Go to your Supabase dashboard
2. Navigate to **Authentication** → **Providers**
3. Enable **Email** provider (it should be enabled by default)
4. Configure email templates if needed

## Step 2: Create Your Admin User

You have two options:

### Option A: Using Supabase Dashboard (Recommended)

1. Go to **Authentication** → **Users**
2. Click **Add User**
3. Enter your admin email and password
4. Click **Create User**
5. ✅ Done! You can now login at `/login.html`

### Option B: Using SQL (Advanced)

Run this SQL in your Supabase SQL Editor:

```sql
-- This will create a user via the auth system
-- Replace with your desired email and password
SELECT auth.create_user(
    email => 'admin@example.com',
    password => 'your-secure-password',
    email_confirm => true
);
```

## Step 3: Test Authentication

1. **Start your local server:**
   ```bash
   python -m http.server 8000
   ```

2. **Visit the login page:**
   ```
   http://localhost:8000/login.html
   ```

3. **Login with your credentials:**
   - Enter your admin email
   - Enter your password
   - Click "Sign In"

4. **You should be redirected to `/admin.html`**

## Step 4: Security Best Practices

### Restrict Admin Access (Optional but Recommended)

You can add role-based access control to ensure only specific users can access admin:

1. **Add a custom claim to your user:**
   ```sql
   -- Mark specific users as admin
   UPDATE auth.users
   SET raw_app_meta_data =
     raw_app_meta_data || '{"role":"admin"}'::jsonb
   WHERE email = 'admin@example.com';
   ```

2. **Update admin.html authentication check:**

   Replace the `checkAuth()` function in `admin.html` with:

   ```javascript
   async function checkAuth() {
       if (!client) {
           window.location.href = 'login.html';
           return false;
       }

       const { data: { session }, error } = await client.auth.getSession();

       if (error || !session) {
           window.location.href = 'login.html';
           return false;
       }

       // Check for admin role
       const userRole = session.user.app_metadata?.role;
       if (userRole !== 'admin') {
           alert('Access denied. Admin privileges required.');
           await client.auth.signOut();
           window.location.href = 'login.html';
           return false;
       }

       document.getElementById('user-email').textContent = session.user.email;
       return true;
   }
   ```

## How It Works

### Login Flow

1. User visits `/admin.html` directly
2. Page checks for active session using `client.auth.getSession()`
3. If no session → redirect to `/login.html`
4. User enters credentials
5. Supabase authenticates via `client.auth.signInWithPassword()`
6. On success → redirect back to `/admin.html`
7. Session persists in browser localStorage

### Protected Routes

- `/admin.html` - Protected (requires authentication)
- `/login.html` - Public (auto-redirects if already logged in)
- `/index.html` - Public
- `/page.html` - Public

## Troubleshooting

### "Login failed" error

- ✅ Check that you created the user correctly in Supabase
- ✅ Verify email/password are correct
- ✅ Check browser console for detailed error messages

### Infinite redirect loop

- ✅ Clear browser localStorage
- ✅ Check that Supabase credentials in `config.js` are correct
- ✅ Verify the user exists in Authentication → Users

### "Supabase not configured" error

- ✅ Make sure `config.js` has correct credentials
- ✅ Check that `SUPABASE_URL` and `SUPABASE_ANON_KEY` are set

## Managing Users

### Add More Admin Users

```sql
-- Create additional admin users
SELECT auth.create_user(
    email => 'another-admin@example.com',
    password => 'secure-password',
    email_confirm => true
);

-- Grant admin role
UPDATE auth.users
SET raw_app_meta_data =
  raw_app_meta_data || '{"role":"admin"}'::jsonb
WHERE email = 'another-admin@example.com';
```

### Reset Password

Users can't reset passwords yet in the current setup. To add password reset:

1. Enable password recovery emails in Supabase dashboard
2. Add a "Forgot Password" link to `login.html`
3. Use `client.auth.resetPasswordForEmail(email)`

### Revoke Access

Delete the user from **Authentication** → **Users** in Supabase dashboard.

## Next Steps

- [ ] Set up email templates for better UX
- [ ] Add "Remember Me" functionality
- [ ] Implement password reset flow
- [ ] Add user profile management
- [ ] Set up two-factor authentication (2FA)

## Production Deployment

When deploying to Vercel:

1. ✅ Your authentication will work automatically (no additional config)
2. ✅ Update the URLs in `index.html` Open Graph tags to your production domain
3. ✅ Consider setting up email templates in Supabase for production
4. ✅ Enable email confirmations for new signups

---

🎉 **You're all set!** Your admin panel is now protected with authentication.
