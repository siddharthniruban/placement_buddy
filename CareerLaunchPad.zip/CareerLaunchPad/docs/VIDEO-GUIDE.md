# 🎥 Video Management Guide

Complete guide to adding and managing YouTube and Instagram videos on your Career LaunchPad site.

---

## ✅ What's Included

You now have a complete video management system:

1. **Videos Database Table** - Store video metadata in Supabase
2. **Admin Video Manager** (`admin-videos.html`) - Easy interface to add/edit videos
3. **Public Video Gallery** (`videos.html`) - Beautiful video showcase page
4. **Category Filtering** - Filter by placement, tutorial, interview, etc.
5. **Tag System** - Organize with custom tags
6. **Video Modal** - Full-screen video player

---

## 🚀 Quick Setup (5 minutes)

### Step 1: Create Videos Table

Run this SQL in your Supabase SQL Editor:

```sql
-- Copy the entire contents of docs/VIDEO-SETUP.sql
```

Or simply run: **[docs/VIDEO-SETUP.sql](./VIDEO-SETUP.sql)**

This creates:
- ✅ `videos` table with all necessary columns
- ✅ Indexes for fast filtering
- ✅ Row Level Security policies
- ✅ Sample video entries (optional)

### Step 2: Test the Admin Panel

1. **Login** at `/login.html` (with your admin credentials)
2. **Click "Videos"** in the navigation
3. **You should see** the video management interface

### Step 3: Add Your First Video

1. **Get a YouTube URL**
   - Example: `https://www.youtube.com/watch?v=dQw4w9WgXcQ`

2. **Fill the form:**
   - Platform: YouTube
   - Title: "Top 5 Interview Tips"
   - URL: Paste your YouTube link
   - Category: Placement
   - Description: Brief description
   - Tags: interview, tips (press Enter after each)
   - Published: ✅ Checked

3. **Click "Save Video"**

4. **Visit** `/videos.html` to see your video gallery!

---

## 📺 Supported Platforms

### YouTube

**URL Formats Supported:**
```
https://www.youtube.com/watch?v=VIDEO_ID
https://youtu.be/VIDEO_ID
```

**Features:**
- ✅ Auto-thumbnail extraction
- ✅ Embedded player
- ✅ Duration display
- ✅ Auto-play in modal

**Example:**
```
URL: https://www.youtube.com/watch?v=dQw4w9WgXcQ
Thumbnail: Auto-generated from YouTube
```

### Instagram

**URL Format:**
```
https://www.instagram.com/p/POST_ID/
```

**Features:**
- ✅ Instagram embed support
- ✅ Reel and Post support
- ✅ Mobile-friendly

**Example:**
```
URL: https://www.instagram.com/p/ABC123/
Note: Instagram videos load via their embed script
```

### Other Platforms

You can also add:
- Vimeo
- TikTok
- LinkedIn videos
- Custom video URLs

Just paste the URL and select "Other" platform.

---

## 🎯 Video Categories

Pre-configured categories:

| Category | Use For |
|----------|---------|
| **Placement** | Job placement tips, company insights |
| **Tutorial** | Coding tutorials, how-to guides |
| **Interview** | Interview preparation, mock interviews |
| **Motivation** | Motivational content, success stories |
| **Career** | Career advice, industry insights |
| **Other** | Anything else |

You can add more categories by:
1. Editing `admin-videos.html` (line ~80)
2. Adding new `<option>` in category dropdown

---

## 🏷️ Using Tags

Tags help organize and filter videos.

**Good tag examples:**
- Technical: `arrays`, `dp`, `trees`, `coding`
- Topics: `interview`, `tips`, `tutorial`, `beginner`
- Companies: `google`, `amazon`, `microsoft`
- Skills: `problem-solving`, `communication`

**How to add tags:**
1. Type tag name in the tag field
2. Press **Enter**
3. Tag appears as a badge
4. Repeat for more tags
5. Click × to remove a tag

**Best practices:**
- Use 3-5 tags per video
- Keep tags short (1-2 words)
- Use lowercase
- Be consistent (decide: "interview" vs "interviews")

---

## 📋 Video Table Schema

Understanding the database structure:

```sql
videos table:
├── id                  UUID (auto-generated)
├── title              TEXT (required) - Video title
├── description        TEXT - Short description
├── video_url          TEXT (required) - YouTube/Instagram URL
├── platform           TEXT - 'youtube', 'instagram', 'other'
├── thumbnail_url      TEXT - Custom thumbnail (optional)
├── category           TEXT - 'placement', 'tutorial', etc.
├── tags               TEXT[] - Array of tag strings
├── duration           TEXT - "10:30" or "1:25:00"
├── views              INTEGER - View counter
├── published          BOOLEAN - Visibility flag
├── order_index        INTEGER - Display order
├── created_at         TIMESTAMP - Auto-set
└── updated_at         TIMESTAMP - Auto-updated
```

---

## 🎨 Customizing the Video Gallery

### Change Layout

Edit `videos.html`:

```css
/* Current: 3-4 columns */
.video-grid {
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
}

/* For 2 columns max: */
.video-grid {
    grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
}

/* For larger cards: */
.video-grid {
    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
}
```

### Add More Categories

1. **Update admin-videos.html:**
```html
<option value="your-new-category">Your New Category</option>
```

2. **Update videos.html:**
```html
<button class="filter-tab" data-category="your-new-category">
    Your New Category
</button>
```

3. **Update formatCategory function:**
```javascript
function formatCategory(category) {
    const names = {
        // ... existing
        'your-new-category': 'Your New Category'
    };
    return names[category] || category;
}
```

### Custom Thumbnails

By default, YouTube thumbnails are auto-generated. To use custom thumbnails:

1. **Upload image to Supabase Storage:**
   - Storage → Create bucket: `video-thumbnails`
   - Upload your image
   - Copy public URL

2. **In admin panel:**
   - Leave `thumbnail_url` field (not visible by default)
   - Or add it to the form:
```html
<div class="form-group">
    <label for="thumbnail_url">Custom Thumbnail URL</label>
    <input type="url" id="thumbnail_url" name="thumbnail_url">
</div>
```

---

## 📊 Tracking Video Views

Currently, views are stored but not automatically incremented. To add view tracking:

### Option 1: Track on Modal Open

Add to `videos.html`:

```javascript
async function openVideo(video) {
    // ... existing code ...

    // Increment view count
    await client
        .from('videos')
        .update({ views: (video.views || 0) + 1 })
        .eq('id', video.id);

    modal.classList.add('active');
}
```

### Option 2: Track on External Link

If you want to track when users go to YouTube:

```javascript
// Make video cards link directly to YouTube
function createVideoCard(video) {
    const card = document.createElement('a');
    card.href = video.video_url;
    card.target = '_blank';
    card.onclick = async (e) => {
        // Track view
        await client
            .from('videos')
            .update({ views: (video.views || 0) + 1 })
            .eq('id', video.id);
    };
    // ... rest of card creation
}
```

---

## 🔗 Integration Ideas

### 1. Embed Videos in Learning Pages

In any page (via admin panel HTML content):

```html
<section class="content-section">
    <div class="container">
        <h2>Related Videos</h2>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1rem;">
            <!-- Video 1 -->
            <div>
                <iframe width="100%" height="200"
                    src="https://www.youtube.com/embed/YOUR_VIDEO_ID"
                    frameborder="0" allowfullscreen>
                </iframe>
                <p style="margin-top: 0.5rem;">
                    <a href="/videos.html">More Videos →</a>
                </p>
            </div>
        </div>
    </div>
</section>
```

### 2. Homepage Video Section

Add to `index.html`:

```html
<!-- After resources section -->
<section class="content-section" style="background: #f9fafb;">
    <div class="container" style="text-align: center;">
        <h2>📺 Latest Videos</h2>
        <p>Watch our latest tutorials and placement tips</p>
        <a href="videos.html" class="cta-button">View All Videos</a>
    </div>
</section>
```

### 3. Featured Video Banner

Add a hero video to homepage:

```html
<section style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 3rem 0;">
    <div class="container" style="text-align: center; color: white;">
        <h2>🎥 Featured: Top Interview Tips</h2>
        <div style="max-width: 800px; margin: 2rem auto;">
            <iframe width="100%" height="450"
                src="https://www.youtube.com/embed/YOUR_FEATURED_VIDEO"
                frameborder="0" allowfullscreen
                style="border-radius: 12px;">
            </iframe>
        </div>
    </div>
</section>
```

---

## 📱 Mobile Optimization

The video gallery is already mobile-friendly:

✅ **Responsive grid** - 1 column on mobile
✅ **Touch-friendly cards** - Large tap targets
✅ **Mobile-optimized modal** - Full-screen on small devices
✅ **Instagram embeds** - Work natively on mobile

---

## 🎬 Advanced Features

### Add Video Playlist

Create playlists by adding a new table:

```sql
CREATE TABLE playlists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    video_ids UUID[] -- Array of video IDs
);
```

### Add Comments

Let users comment on videos:

```sql
CREATE TABLE video_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id UUID REFERENCES videos(id),
    user_id UUID REFERENCES auth.users(id),
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### Add Favorites/Bookmarks

Let users save favorite videos:

```sql
CREATE TABLE video_favorites (
    user_id UUID REFERENCES auth.users(id),
    video_id UUID REFERENCES videos(id),
    created_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (user_id, video_id)
);
```

---

## 🐛 Troubleshooting

### Video not embedding

**YouTube:**
- ✅ Check URL format: `youtube.com/watch?v=ID` or `youtu.be/ID`
- ✅ Verify video is not private/restricted
- ✅ Check browser console for errors

**Instagram:**
- ✅ Make sure post is public
- ✅ Wait for Instagram embed script to load
- ✅ Check internet connection

### Thumbnails not showing

- ✅ For YouTube: Auto-generated from video ID
- ✅ For Instagram: Use placeholder or custom thumbnail
- ✅ Check image URL is accessible

### Videos not appearing

- ✅ Check `published` is set to `true`
- ✅ Verify RLS policies are set correctly
- ✅ Check browser console for Supabase errors
- ✅ Hard refresh page (Cmd+Shift+R)

### Modal not opening

- ✅ Check JavaScript console for errors
- ✅ Verify video URL is valid
- ✅ Clear browser cache

---

## 📈 SEO for Videos

The video gallery page is already SEO-optimized with:

✅ **Meta tags** - Title, description, keywords
✅ **Open Graph** - Social sharing previews
✅ **Semantic HTML** - Proper heading structure

To improve further:

### Add Video Schema

Add to individual video cards:

```html
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "VideoObject",
    "name": "Video Title",
    "description": "Video description",
    "thumbnailUrl": "thumbnail-url",
    "uploadDate": "2025-01-15",
    "contentUrl": "youtube-url"
}
</script>
```

### Video Sitemap

Create `video-sitemap.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
    <url>
        <loc>https://your-domain.com/videos.html</loc>
        <video:video>
            <video:thumbnail_loc>thumbnail-url</video:thumbnail_loc>
            <video:title>Video Title</video:title>
            <video:description>Description</video:description>
            <video:content_loc>youtube-url</video:content_loc>
        </video:video>
    </url>
</urlset>
```

---

## ✅ Quick Checklist

Before launching video feature:

- [ ] Run VIDEO-SETUP.sql in Supabase
- [ ] Test admin-videos.html (add/edit/delete)
- [ ] Add at least 3 sample videos
- [ ] Test videos.html gallery
- [ ] Try category filtering
- [ ] Test video modal (click to play)
- [ ] Check mobile responsiveness
- [ ] Verify YouTube embeds work
- [ ] Test Instagram embeds (if using)
- [ ] Update navigation links
- [ ] Test on production (after deploy)

---

## 🎯 Best Practices

1. **Consistent thumbnails** - Use high-quality YouTube thumbnails
2. **Clear titles** - Descriptive, SEO-friendly
3. **Good descriptions** - 1-2 sentences explaining video
4. **Organize with tags** - Makes content discoverable
5. **Set duration** - Helps users know time commitment
6. **Use categories** - Keep content organized
7. **Regular updates** - Add new videos weekly/monthly
8. **Engage viewers** - Ask for comments/feedback

---

## 📚 Summary

You now have:
- ✅ Complete video management system
- ✅ Admin interface for videos
- ✅ Public video gallery
- ✅ YouTube and Instagram support
- ✅ Category filtering and tags
- ✅ Mobile-responsive design
- ✅ SEO-optimized pages

**Next steps:**
1. Run the SQL setup
2. Add your first video
3. Share your video gallery!

---

**Questions?** Check:
- Supabase logs for database errors
- Browser console for JavaScript errors
- Video URLs are correct and public

---

*Last updated: 2025-01-15*
*Ready to showcase your videos!* 🎥
