# 👥 User Login & Signup System - Setup Guide

Complete guide to enable student accounts on Career LaunchPad.

---

## ✅ What's Included

Your platform now has:

- ✅ **Signup Page** (`signup.html`) - Students can create accounts
- ✅ **Login Page** (`login.html`) - Updated to support all users
- ✅ **Dashboard** (`dashboard.html`) - Personal dashboard for each student
- ✅ **Social Login Ready** - Google & GitHub OAuth (needs configuration)
- ✅ **Admin Detection** - Admins see "Admin Panel" link in dashboard

---

## 🚀 Quick Start

### Step 1: Enable Email Authentication in Supabase

1. Go to your Supabase Dashboard
2. Navigate to **Authentication** → **Providers**
3. Make sure **Email** provider is enabled
4. Configure email templates (optional but recommended):
   - Confirmation email
   - Password reset email
   - Magic link email

### Step 2: Configure Email Confirmation (Optional)

**Option A: Disable Email Confirmation (Quick Start)**
- Good for testing and small communities
- Users can login immediately after signup

1. Go to **Authentication** → **Providers** → **Email**
2. Turn OFF "Confirm email"
3. Save

**Option B: Enable Email Confirmation (Recommended for Production)**
- More secure
- Prevents fake accounts
- Users must verify email before logging in

1. Keep "Confirm email" ON
2. Customize confirmation email template in **Authentication** → **Email Templates**

### Step 3: Test the System

1. Open `signup.html` in your browser
2. Create a test account with your email
3. If email confirmation is ON, check your email and click the link
4. Login via `login.html`
5. You should be redirected to `dashboard.html`

---

## 👨‍💼 Admin Access

### How Admins Work

The system has a simple admin detection mechanism:

**In `dashboard.html` line 320:**
```javascript
const ADMIN_EMAILS = ['your-admin-email@example.com'];
```

**To make yourself an admin:**

1. Open `dashboard.html`
2. Find line 320 (or search for `ADMIN_EMAILS`)
3. Replace `'your-admin-email@example.com'` with your actual email
4. Example:
   ```javascript
   const ADMIN_EMAILS = ['admin@careerlaunchpad.com', 'you@gmail.com'];
   ```

5. Save the file

Now when you login with that email:
- You'll see "Admin Panel" button in dashboard
- You can access both student dashboard AND admin panel
- Regular students won't see admin features

---

## 🎨 Enable Social Login (Optional)

### Google OAuth

1. **Create Google OAuth App:**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing
   - Enable Google+ API
   - Create OAuth 2.0 credentials
   - Add authorized redirect URIs:
     - `https://your-project.supabase.co/auth/v1/callback`

2. **Configure in Supabase:**
   - Go to **Authentication** → **Providers**
   - Enable Google
   - Enter Client ID and Client Secret
   - Save

3. **Update Redirect URL:**
   - In `signup.html` line 285, the redirect is already set
   - Test by clicking "Google" button on signup page

### GitHub OAuth

1. **Create GitHub OAuth App:**
   - Go to GitHub Settings → Developer settings → OAuth Apps
   - Click "New OAuth App"
   - Set Authorization callback URL:
     - `https://your-project.supabase.co/auth/v1/callback`

2. **Configure in Supabase:**
   - Go to **Authentication** → **Providers**
   - Enable GitHub
   - Enter Client ID and Client Secret
   - Save

3. **Test:**
   - Click "GitHub" button on signup page

---

## 📊 Features Overview

### Signup Page Features
- Email/password registration
- Full name capture
- Password requirements
- Terms & conditions checkbox
- Social login buttons (Google, GitHub)
- Link to login page
- Auto-redirect if already logged in

### Login Page Features
- Email/password login
- Link to signup page
- Auto-redirect if already logged in
- Redirects to dashboard after login
- Error handling

### Dashboard Features
- **Welcome banner** with user name
- **Stats cards:**
  - Day streak (🔥)
  - Topics completed (📚)
  - Points earned (⭐)
  - Rank (🏆)
- **Quick actions:**
  - Browse topics
  - Watch videos
  - View roadmap
  - Join community
- **Progress section:**
  - Topic-wise progress bars
  - Visual progress tracking
- **Recent activity:**
  - Activity timeline
- **Admin link** (for admin users only)
- **Logout button**

---

## 🔄 Navigation Updates Needed

To show Login/Signup or Dashboard based on auth state, update your navigation in `index.html`, `videos.html`, and `roadmap.html`:

### Add this JavaScript before closing `</body>` tag:

```html
<script src="config.js"></script>
<script>
    // Update navigation based on auth state
    async function updateNav() {
        const client = initSupabase();
        if (!client) return;

        const { data: { session } } = await client.auth.getSession();
        const navLinks = document.querySelector('.nav-links');

        if (session) {
            // User is logged in - show Dashboard
            const dashboardLink = navLinks.querySelector('a[href="login.html"]');
            if (dashboardLink) {
                dashboardLink.href = 'dashboard.html';
                dashboardLink.textContent = 'Dashboard';
            }
        } else {
            // User is not logged in - show Login/Signup
            const loginLink = navLinks.querySelector('a[href="dashboard.html"]');
            if (loginLink) {
                loginLink.href = 'login.html';
                loginLink.textContent = 'Login';
            }
        }
    }

    updateNav();
</script>
```

---

## 🔐 Security Best Practices

### Row Level Security (RLS)

When you add user-specific features (progress tracking, comments), enable RLS:

```sql
-- Example for user_progress table
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own progress"
ON user_progress FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
ON user_progress FOR UPDATE
USING (auth.uid() = user_id);
```

### Password Requirements

Currently set to minimum 6 characters. To increase security:

1. Open `signup.html`
2. Find line 232: `minlength="6"`
3. Change to `minlength="8"` or higher
4. Update the requirements text below it

### Admin Protection

For admin pages (`admin.html`, `admin-videos.html`), they already have auth checks.

To add role-based access (instead of email-based):

1. Create a `user_roles` table in Supabase
2. Add role column: `admin`, `student`, `moderator`
3. Check role in dashboard instead of email array

---

## 🎯 Next Steps: Progress Tracking

Once users are logging in, implement progress tracking:

### Database Schema

```sql
CREATE TABLE user_progress (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    page_id UUID REFERENCES pages(id) ON DELETE CASCADE,
    completed BOOLEAN DEFAULT false,
    last_visited TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, page_id)
);

CREATE TABLE user_stats (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    total_points INT DEFAULT 0,
    last_activity_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### Features to Add

1. **Mark as Complete** button on each page
2. **Streak tracking** based on daily activity
3. **Points system** for completing topics
4. **Leaderboard** showing top students
5. **Badges** for achievements

---

## 🐛 Troubleshooting

### "User already registered" Error

**Cause:** Email already exists in database

**Solution:**
- Use a different email, OR
- Reset password for existing email, OR
- Delete user from Supabase Auth dashboard

### Email Confirmation Not Sending

**Check:**
1. Email provider is configured in Supabase
2. Email templates are set up
3. Check spam folder
4. Verify sender email is confirmed

**Quick Fix:**
- Disable email confirmation temporarily (see Step 2 above)

### Social Login Not Working

**Common Issues:**
1. OAuth app not configured in Supabase
2. Redirect URI mismatch
3. OAuth app credentials incorrect

**Debug:**
- Check browser console for errors
- Verify redirect URI exactly matches in both places
- Test with email login first to isolate issue

### Dashboard Shows "User" Instead of Name

**Cause:** User signed up before full_name field was added

**Solution:**
1. User can update profile (add profile edit feature), OR
2. Admin can update user metadata in Supabase dashboard

---

## 📱 Mobile Responsive

All pages (signup, login, dashboard) are mobile-responsive:
- Stack elements vertically on small screens
- Readable font sizes
- Touch-friendly buttons
- Responsive grids

Test on mobile:
1. Open Chrome DevTools (F12)
2. Toggle device toolbar (Ctrl+Shift+M)
3. Test on different screen sizes

---

## 🎨 Customization

### Change Colors

Update the gradient colors in all pages:

**Current gradient:**
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

**To change:**
Replace `#667eea` and `#764ba2` with your brand colors.

### Add More Stats

In `dashboard.html`, add more stat cards:

```html
<div class="stat-card">
    <div class="stat-card-header">
        <span class="stat-icon">📝</span>
    </div>
    <div class="stat-value">0</div>
    <div class="stat-label">Mock Tests Taken</div>
</div>
```

### Customize Welcome Message

Edit line 242 in `dashboard.html`:

```html
<p>Keep up the great work on your placement journey</p>
```

---

## 💡 Feature Ideas for Future

1. **Profile Page:**
   - Edit name, email
   - Upload profile picture
   - Set target companies
   - Preparation goals

2. **Achievements System:**
   - Unlock badges
   - View all achievements
   - Share on social media

3. **Study Buddy Matching:**
   - Find peers preparing for same companies
   - Study groups
   - Practice interviews together

4. **Daily Challenges:**
   - One problem per day
   - Bonus points for daily streaks
   - Leaderboard for challenges

5. **Premium Features:**
   - Extended analytics
   - Personalized study plan
   - 1-on-1 mentor sessions
   - Mock interviews with feedback

---

## 📧 Support

If you face issues:
1. Check browser console for errors
2. Verify Supabase connection in `config.js`
3. Test with a fresh incognito window
4. Check Supabase Auth logs for debugging

---

**System is ready! Students can now:**
- ✅ Sign up for accounts
- ✅ Login and access dashboard
- ✅ See their personalized space
- ✅ Access all platform features

**Next: Implement progress tracking to make the stats functional!**

---

*Last updated: 2025-01-16*
*Version: 1.0 - Initial User Login System*
