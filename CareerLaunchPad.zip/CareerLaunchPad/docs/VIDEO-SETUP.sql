-- ============================================
-- Video Management System Setup
-- ============================================
-- Creates a dedicated table for managing YouTube/Instagram videos
-- Run this in your Supabase SQL Editor
-- ============================================

-- 1. CREATE VIDEOS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS videos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT NOT NULL,
    platform TEXT NOT NULL CHECK (platform IN ('youtube', 'instagram', 'other')),
    thumbnail_url TEXT,
    category TEXT DEFAULT 'placement',
    tags TEXT[], -- Array of tags like ['interview', 'tips', 'coding']
    duration TEXT, -- e.g., "10:30"
    views INTEGER DEFAULT 0,
    published BOOLEAN DEFAULT true,
    order_index INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. CREATE INDEXES
-- ============================================

CREATE INDEX IF NOT EXISTS idx_videos_platform ON videos(platform);
CREATE INDEX IF NOT EXISTS idx_videos_category ON videos(category);
CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(published);
CREATE INDEX IF NOT EXISTS idx_videos_tags ON videos USING GIN(tags);

-- 3. ENABLE ROW LEVEL SECURITY
-- ============================================

ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- 4. CREATE RLS POLICIES
-- ============================================

-- Anyone can view published videos
CREATE POLICY "Public videos are viewable by everyone"
ON videos FOR SELECT
USING (published = true);

-- Authenticated users (admins) can manage videos
CREATE POLICY "Authenticated users can manage videos"
ON videos FOR ALL
USING (auth.role() = 'authenticated');

-- 5. CREATE AUTO-UPDATE TRIGGER FUNCTION (if not exists)
-- ============================================

-- First, create the function if it doesn't already exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Then create the trigger for videos table
DROP TRIGGER IF EXISTS update_videos_updated_at ON videos;
CREATE TRIGGER update_videos_updated_at
    BEFORE UPDATE ON videos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 6. SAMPLE VIDEO ENTRIES
-- ============================================

INSERT INTO videos (title, description, video_url, platform, category, tags, duration, thumbnail_url)
VALUES
(
    'Top 5 Interview Tips for Software Engineers',
    'Essential tips to ace your next technical interview',
    'https://www.youtube.com/watch?v=YOUR_VIDEO_ID',
    'youtube',
    'placement',
    ARRAY['interview', 'tips', 'career'],
    '12:45',
    'https://img.youtube.com/vi/YOUR_VIDEO_ID/maxresdefault.jpg'
),
(
    'Cracking the Coding Interview - Arrays',
    'Step-by-step guide to solving array problems',
    'https://www.youtube.com/watch?v=YOUR_VIDEO_ID',
    'youtube',
    'tutorial',
    ARRAY['arrays', 'coding', 'tutorial'],
    '25:30',
    'https://img.youtube.com/vi/YOUR_VIDEO_ID/maxresdefault.jpg'
),
(
    'Day in the Life - Software Engineer at FAANG',
    'Behind the scenes at a top tech company',
    'https://www.instagram.com/p/YOUR_POST_ID/',
    'instagram',
    'placement',
    ARRAY['career', 'lifestyle', 'motivation'],
    '0:60',
    NULL
);

-- 7. HELPER FUNCTION TO EXTRACT YOUTUBE ID
-- ============================================

CREATE OR REPLACE FUNCTION extract_youtube_id(url TEXT)
RETURNS TEXT AS $$
BEGIN
    -- Extract from youtube.com/watch?v=ID
    IF url LIKE '%youtube.com/watch?v=%' THEN
        RETURN substring(url from 'v=([^&]+)');
    -- Extract from youtu.be/ID
    ELSIF url LIKE '%youtu.be/%' THEN
        RETURN substring(url from 'youtu\.be/([^?]+)');
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- Setup Complete! ✅
-- ============================================
-- Next steps:
-- 1. Create video admin page to manage videos
-- 2. Create video gallery page to display them
-- 3. Add videos via admin interface
-- ============================================
