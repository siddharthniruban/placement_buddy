# 🏆 Daily Challenge System - Complete Guide

Give students a new coding challenge every 24 hours with bonus points!

---

## 🚀 Quick Setup (5 Minutes)

### Step 1: Run SQL Setup

1. Open **Supabase Dashboard**
2. Go to **SQL Editor** → **New Query**
3. Copy ALL content from `docs/DAILY-CHALLENGE-SETUP.sql`
4. Click **Run**
5. Wait for "Success" message

**This creates:**
- ✅ `daily_challenges` table - Library of challenges
- ✅ `daily_challenge_schedule` table - Which challenge for which day
- ✅ `daily_challenge_completions` table - User completions
- ✅ Auto-rotation function - Picks new challenge daily
- ✅ Leaderboard function - Shows fastest completions
- ✅ 5 starter challenges - Ready to go!

### Step 2: Test It!

1. Visit **http://localhost:8000/daily-challenge.html**
2. You'll see today's automatically selected challenge
3. Login/signup to mark as complete
4. Earn **20 bonus points** (instead of regular 10)!

---

## 🎯 How It Works

### Daily Challenge Flow

**For Everyone (Logged In or Not):**
1. **New challenge every 24 hours** at midnight
2. **Auto-selected** from challenge library
3. **Won't repeat** for 30 days
4. **Full problem statement** visible to all
5. **Progressive hints** available
6. **Countdown timer** shows time until next challenge

**For Logged-In Users:**
- Click "Mark as Complete" when solved
- Earn **20 bonus points** (2x regular completion)
- Appear on today's leaderboard
- Counted toward streak
- Added to activity log

**For Non-Logged-In Users:**
- Can read full challenge
- Can view hints
- See login prompt to earn points
- Encouraged to create account

### Challenge Selection Logic

The system automatically:
1. Checks if challenge scheduled for today
2. If not, picks random challenge that:
   - Is active (not disabled)
   - Hasn't been used in last 30 days
3. Schedules it for today
4. Same challenge all day for all users
5. New challenge at midnight

---

## 📊 What's Included

### Challenge Details

Each challenge has:
- **Title** - Short, catchy name
- **Description** - One-line summary
- **Difficulty** - Easy, Medium, Hard (with color badges)
- **Category** - Array, LinkedList, DP, etc.
- **Problem Statement** - Full problem description
- **Hints** - Progressive hints (click to reveal)
- **Bonus Points** - Default 20 points
- **Time Limit** - Optional (default 45 min)

### 5 Starter Challenges

The SQL automatically creates:
1. **Two Sum** (Easy, Array) - 20 points
2. **Valid Parentheses** (Easy, Stack) - 20 points
3. **Merge Two Sorted Lists** (Easy, Linked List) - 20 points
4. **Maximum Subarray** (Medium, Array) - 30 points
5. **Climbing Stairs** (Easy, DP) - 20 points

### Leaderboard Features

- Shows top 10 completions for today
- Ranks by completion time (first = best)
- Medals for top 3: 🥇 🥈 🥉
- Shows username and completion time
- Updates in real-time
- Resets every 24 hours

---

## 🛠️ Customization

### Add More Challenges

Via Supabase SQL Editor:

```sql
INSERT INTO daily_challenges (
    title,
    description,
    difficulty,
    category,
    problem_statement,
    hints,
    bonus_points,
    time_limit_minutes
)
VALUES (
    'Binary Search',
    'Search efficiently in sorted array',
    'easy',
    'Array',
    'Given a sorted array nums and target value, return index of target.
    If not found, return -1.

    Example:
    Input: nums = [-1,0,3,5,9,12], target = 9
    Output: 4',
    ARRAY[
        'Use divide and conquer approach',
        'Compare middle element with target',
        'Eliminate half of array each iteration'
    ],
    20,
    30
);
```

### Via Admin Panel (Future Enhancement)

You could add a page to manage challenges:
- Create new challenges
- Edit existing ones
- Disable/enable challenges
- Preview challenges
- Schedule specific challenges for specific dates

### Change Bonus Points

**Per Challenge:**
Edit in database or when inserting:
```sql
UPDATE daily_challenges
SET bonus_points = 30
WHERE difficulty = 'medium';
```

**Globally:**
Edit `daily-challenge.html` line in markAsComplete():
```javascript
points_earned: currentChallenge.bonus_points * 2 // Double points!
```

### Schedule Specific Challenges

Instead of auto-rotation, schedule manually:

```sql
-- Schedule specific challenge for specific date
INSERT INTO daily_challenge_schedule (challenge_date, challenge_id)
VALUES (
    '2025-01-20',
    (SELECT id FROM daily_challenges WHERE title = 'Two Sum')
);
```

### Modify Time Limit

```sql
UPDATE daily_challenges
SET time_limit_minutes = 60
WHERE difficulty = 'hard';
```

---

## 📈 Engagement Strategy

### Daily Habit Building

**Morning Post (WhatsApp/Email):**
```
🌅 Good morning! Today's challenge is here:

🏆 [Challenge Title]
⏰ [Difficulty] | ⭐ +20 bonus points
🔗 [Link]

First to solve gets top spot on leaderboard! 🥇
```

**Evening Reminder:**
```
⏰ Only 4 hours left for today's challenge!

Current leaderboard:
🥇 Rahul - 2h ago
🥈 Priya - 3h ago
🥉 Amit - 4h ago

Can you beat them? 🏃‍♂️
```

### Weekly Challenges (Optional)

For special events:
- **Monday:** Easy challenge (warm-up)
- **Wednesday:** Medium challenge
- **Friday:** Hard challenge (weekend prep)
- **Sunday:** Fun challenge (creative problem)

### Monthly Champions

Track monthly stats:
- Most challenges completed
- Fastest average time
- Most consistent solver
- Bonus: Extra 100 points for monthly winner

---

## 🎨 UI Features

### Current Features

**Challenge Page:**
- ✅ Beautiful gradient header
- ✅ Countdown timer to next challenge
- ✅ Difficulty badge with colors
- ✅ Category and bonus points display
- ✅ Code-style problem statement
- ✅ Progressive hints (click to reveal)
- ✅ "Mark as Complete" button
- ✅ Success celebration on completion
- ✅ Today's leaderboard
- ✅ Login prompt for non-users

**Responsive Design:**
- ✅ Works on mobile
- ✅ Touch-friendly buttons
- ✅ Readable on small screens

### Future Enhancements

**1. Code Editor Integration:**
```javascript
// Use Monaco Editor or CodeMirror
<div id="code-editor"></div>
// Let users write and test solutions
```

**2. Test Cases:**
```javascript
// Add test cases to challenges
test_cases: [
    { input: [2,7,11,15], target: 9, expected: [0,1] },
    { input: [3,2,4], target: 6, expected: [1,2] }
]
```

**3. Solutions Tab:**
```javascript
// Show optimal solution after completion
solution_code: `
function twoSum(nums, target) {
    const map = new Map();
    for (let i = 0; i < nums.length; i++) {
        const complement = target - nums[i];
        if (map.has(complement)) {
            return [map.get(complement), i];
        }
        map.set(nums[i], i);
    }
}
`
```

**4. Discuss Section:**
- Let users comment on challenges
- Share alternative approaches
- Ask for clarifications

---

## 📊 Analytics Queries

### Most Popular Challenges

```sql
SELECT
    dc.title,
    dc.difficulty,
    COUNT(dcc.id) as completions
FROM daily_challenges dc
LEFT JOIN daily_challenge_completions dcc ON dcc.challenge_id = dc.id
GROUP BY dc.id, dc.title, dc.difficulty
ORDER BY completions DESC
LIMIT 10;
```

### Completion Rate

```sql
SELECT
    dc.title,
    COUNT(dcc.id) as completions,
    COUNT(DISTINCT dcs.challenge_date) as times_shown,
    (COUNT(dcc.id)::float / NULLIF(COUNT(DISTINCT us.user_id), 0) * 100) as completion_rate
FROM daily_challenges dc
LEFT JOIN daily_challenge_schedule dcs ON dcs.challenge_id = dc.id
LEFT JOIN daily_challenge_completions dcc ON dcc.challenge_id = dc.id
LEFT JOIN user_stats us ON true
GROUP BY dc.id, dc.title
ORDER BY completion_rate DESC;
```

### Daily Engagement

```sql
SELECT
    DATE(dcc.completed_at) as date,
    COUNT(DISTINCT dcc.user_id) as unique_users,
    COUNT(*) as total_completions
FROM daily_challenge_completions dcc
WHERE dcc.completed_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE(dcc.completed_at)
ORDER BY date DESC;
```

---

## 🐛 Troubleshooting

### Issue: No challenge showing

**Check:**
1. SQL setup completed?
2. Are there active challenges in database?

**Debug:**
```sql
SELECT * FROM daily_challenges WHERE is_active = true;
SELECT * FROM daily_challenge_schedule WHERE challenge_date = CURRENT_DATE;
```

**Fix:**
```sql
-- Manually trigger auto-selection
SELECT * FROM get_todays_challenge();
```

### Issue: Can't mark as complete

**Check:**
1. User logged in?
2. Already completed today's challenge?

**Debug in browser console:**
```javascript
const { data: { session } } = await client.auth.getSession();
console.log('Session:', session);
```

### Issue: Leaderboard not showing

**Check:**
1. Has anyone completed today's challenge?
2. RLS policies enabled?

**Debug:**
```sql
SELECT * FROM daily_challenge_completions
WHERE challenge_id = (
    SELECT challenge_id FROM daily_challenge_schedule
    WHERE challenge_date = CURRENT_DATE
);
```

---

## 🎉 Launch Checklist

Before announcing daily challenges:

- [ ] SQL setup completed
- [ ] At least 10 challenges in database
- [ ] Tested marking as complete
- [ ] Tested leaderboard display
- [ ] Tested on mobile
- [ ] Timer countdown working
- [ ] Hints reveal working
- [ ] Points awarded correctly
- [ ] Non-logged-in users see signup prompt
- [ ] WhatsApp announcement ready
- [ ] Promotional graphics created

---

## 📱 Promotion Ideas

### WhatsApp Messages

**Launch Announcement:**
```
🚀 NEW FEATURE: Daily Challenges!

Starting today, get a new coding challenge every 24 hours!

✅ Solve it, earn 20 bonus points
✅ Compete on leaderboard
✅ Build your streak
✅ Free for everyone

Today's challenge: [Title]
Difficulty: [Easy/Medium/Hard]

🔗 [Link]

Let's go! 🔥
```

**Daily Reminder Template:**
```
☀️ Daily Challenge #{number}

🎯 [Challenge Title]
📊 Difficulty: [Level]
⭐ Bonus: +20 points

⏰ 12 hours left!

Current leaders:
🥇 [Name]
🥈 [Name]
🥉 [Name]

Can you beat them?
🔗 [Link]
```

### Social Media Posts

**Twitter/LinkedIn:**
```
🏆 Join 100+ students solving our daily coding challenge!

Today: [Challenge Name]
Level: [Difficulty]
Points: +20 bonus

Think you can solve it? 🤔
[Link]

#CodingChallenge #100DaysOfCode #PlacementPrep
```

---

## 🎯 Success Metrics

### Week 1 Goals
- 20% of active users attempt daily challenge
- 50% completion rate
- 5+ challenges in database

### Month 1 Goals
- 40% of active users attempt daily challenge
- Average 15 completions per day
- Leaderboard has 10+ entries daily
- 20+ challenges in database

### Month 3 Goals
- 60% of active users attempt daily challenge
- Daily challenges are #1 engagement driver
- 50+ challenges in database
- Featured challenges on special occasions

---

## 💡 Next Level Features

1. **Themed Weeks:**
   - Array week
   - DP week
   - Interview prep week

2. **Difficulty Progression:**
   - Monday: Easy
   - Wednesday: Medium
   - Friday: Hard

3. **Challenge Streaks:**
   - Bonus: Complete 7 days in row → +50 points
   - Bonus: Complete 30 days in row → +200 points

4. **Team Challenges:**
   - Form teams of 3-5
   - Combined points
   - Team leaderboard

5. **Live Coding Events:**
   - Saturday special: Live coding challenge
   - Everyone solves at same time
   - Real-time leaderboard updates

---

## ✅ Summary

Your daily challenge system is now **fully functional**!

**Students can:**
- ✅ Get a new challenge every 24 hours
- ✅ Read full problem statement and hints
- ✅ Mark as complete and earn 20 bonus points
- ✅ See their rank on today's leaderboard
- ✅ Build daily solving habit

**You can:**
- ✅ Add unlimited challenges via SQL
- ✅ Control difficulty and points
- ✅ Track engagement metrics
- ✅ Auto-rotate challenges daily

**Next Steps:**
1. Run the SQL setup
2. Visit daily-challenge.html
3. Share with your community!

---

*Last updated: 2025-01-16*
*Version: 1.0 - Daily Challenge System*
