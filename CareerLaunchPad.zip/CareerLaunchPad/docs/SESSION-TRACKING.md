# 🔐 Session & User Tracking - Technical Guide

Complete explanation of how user sessions and activity tracking work in Career LaunchPad.

---

## 📍 Where Sessions Are Stored

### Browser Storage (Current Implementation)

When a user logs in via Supabase, the session is stored in:

**1. Browser localStorage**
- **Key**: `supabase.auth.token`
- **Location**: Browser's localStorage
- **Contains**:
  ```json
  {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "vZXNzIjoxNjc0...",
    "expires_in": 3600,
    "token_type": "bearer",
    "user": {
      "id": "uuid-here",
      "email": "student@example.com",
      "user_metadata": {
        "full_name": "Student Name"
      },
      "created_at": "2025-01-16T10:00:00Z"
    }
  }
  ```

**To View Your Session:**
1. Open browser (Chrome/Firefox)
2. Press F12 to open DevTools
3. Go to **Application** tab → **Local Storage**
4. Click your website URL
5. Look for `supabase.auth.token`
6. You'll see the full session object

---

## 🔄 How Session Checking Works

### On Every Page Load

Each protected page checks if user is logged in:

**Example from `dashboard.html`:**

```javascript
async function checkAuth() {
    // Get Supabase client
    const client = initSupabase();

    if (!client) {
        // Supabase not configured
        window.location.href = 'login.html';
        return false;
    }

    // Get current session from localStorage
    const { data: { session }, error } = await client.auth.getSession();

    if (error || !session) {
        // No valid session - redirect to login
        window.location.href = 'login.html';
        return false;
    }

    // Session exists! Extract user data
    const userName = session.user.user_metadata?.full_name ||
                     session.user.email.split('@')[0];

    const userEmail = session.user.email;
    const userId = session.user.id;

    return true;
}

// Run on page load
checkAuth();
```

### Session Lifecycle

```
User Signs Up/Logs In
        ↓
Supabase creates session
        ↓
Session saved to localStorage
        ↓
User navigates to dashboard.html
        ↓
dashboard.html calls getSession()
        ↓
Supabase reads from localStorage
        ↓
Returns session object
        ↓
Page displays user data
```

---

## ⏰ Session Expiration

### Token Expiry

**Access Token:**
- Default: 1 hour
- After expiry: Auto-refreshed using refresh token

**Refresh Token:**
- Default: 30 days
- After expiry: User must login again

### Auto-Refresh

Supabase automatically refreshes expired access tokens:

```javascript
// Supabase handles this automatically!
client.auth.onAuthStateChange((event, session) => {
    if (event === 'TOKEN_REFRESHED') {
        console.log('Token refreshed automatically');
    }

    if (event === 'SIGNED_OUT') {
        console.log('User signed out');
        window.location.href = 'login.html';
    }
});
```

**To add auto-refresh listener to your pages:**

Add this to `dashboard.html` and other pages:

```javascript
// Listen for auth state changes
client.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_OUT') {
        window.location.href = 'login.html';
    }
});
```

---

## 📊 User Activity Tracking (Not Yet Implemented)

### Current Status

The dashboard shows **placeholder stats**:
- Streak: 0
- Topics Completed: 0
- Points: 0
- Rank: #-

These are hardcoded. **Real tracking requires database tables.**

### How to Implement Real Tracking

#### Step 1: Create Database Tables

Run this SQL in Supabase:

```sql
-- ============================================
-- USER ACTIVITY TRACKING TABLES
-- ============================================

-- Table 1: User Stats
CREATE TABLE IF NOT EXISTS user_stats (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    total_points INT DEFAULT 0,
    topics_completed INT DEFAULT 0,
    last_activity_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table 2: Page Completions
CREATE TABLE IF NOT EXISTS user_progress (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    page_id UUID REFERENCES pages(id) ON DELETE CASCADE,
    completed BOOLEAN DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    last_visited TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, page_id)
);

-- Table 3: Activity Log
CREATE TABLE IF NOT EXISTS user_activity (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    activity_type TEXT NOT NULL, -- 'page_view', 'page_complete', 'video_watch'
    page_id UUID REFERENCES pages(id) ON DELETE SET NULL,
    points_earned INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;

-- Policies: Users can only see/update their own data
CREATE POLICY "Users view own stats"
ON user_stats FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users update own stats"
ON user_stats FOR ALL
USING (auth.uid() = user_id);

CREATE POLICY "Users view own progress"
ON user_progress FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users manage own progress"
ON user_progress FOR ALL
USING (auth.uid() = user_id);

CREATE POLICY "Users view own activity"
ON user_activity FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users insert own activity"
ON user_activity FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create indexes
CREATE INDEX idx_user_progress_user ON user_progress(user_id);
CREATE INDEX idx_user_activity_user ON user_activity(user_id);
CREATE INDEX idx_user_activity_date ON user_activity(created_at DESC);

-- Trigger to auto-update user_stats.updated_at
CREATE TRIGGER update_user_stats_updated_at
    BEFORE UPDATE ON user_stats
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
```

#### Step 2: Track Page Views

Add to every page (at the end of page content):

```javascript
async function trackPageView(pageId) {
    const { data: { session } } = await client.auth.getSession();

    if (!session) return; // Not logged in

    // Insert activity log
    await client
        .from('user_activity')
        .insert([{
            user_id: session.user.id,
            activity_type: 'page_view',
            page_id: pageId
        }]);

    // Update last_visited in user_progress
    await client
        .from('user_progress')
        .upsert({
            user_id: session.user.id,
            page_id: pageId,
            last_visited: new Date().toISOString()
        });
}

// Track when user views page
trackPageView('PAGE_UUID_HERE');
```

#### Step 3: Track Completions

Add "Mark as Complete" button to `page.html`:

```html
<button id="mark-complete-btn" class="btn btn-primary">
    Mark as Complete ✓
</button>

<script>
document.getElementById('mark-complete-btn').addEventListener('click', async () => {
    const { data: { session } } = await client.auth.getSession();

    if (!session) {
        alert('Please login to track progress');
        return;
    }

    const pageId = 'PAGE_UUID_HERE';

    // Mark page as complete
    const { error } = await client
        .from('user_progress')
        .upsert({
            user_id: session.user.id,
            page_id: pageId,
            completed: true,
            completed_at: new Date().toISOString()
        });

    if (error) {
        console.error('Error:', error);
        alert('Failed to mark as complete');
        return;
    }

    // Add activity log with points
    await client
        .from('user_activity')
        .insert([{
            user_id: session.user.id,
            activity_type: 'page_complete',
            page_id: pageId,
            points_earned: 10
        }]);

    // Update user stats
    await updateUserStats(session.user.id);

    alert('Great job! Page marked as complete 🎉');
});

async function updateUserStats(userId) {
    // Get total completed pages
    const { count } = await client
        .from('user_progress')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('completed', true);

    // Get total points
    const { data: activities } = await client
        .from('user_activity')
        .select('points_earned')
        .eq('user_id', userId);

    const totalPoints = activities?.reduce((sum, a) => sum + (a.points_earned || 0), 0) || 0;

    // Calculate streak
    const streak = await calculateStreak(userId);

    // Update user_stats
    await client
        .from('user_stats')
        .upsert({
            user_id: userId,
            topics_completed: count,
            total_points: totalPoints,
            current_streak: streak.current,
            longest_streak: Math.max(streak.current, streak.longest),
            last_activity_date: new Date().toISOString().split('T')[0]
        });
}

async function calculateStreak(userId) {
    // Get all activity dates
    const { data: activities } = await client
        .from('user_activity')
        .select('created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

    if (!activities || activities.length === 0) {
        return { current: 0, longest: 0 };
    }

    // Convert to dates and calculate consecutive days
    const dates = [...new Set(activities.map(a =>
        new Date(a.created_at).toISOString().split('T')[0]
    ))];

    let currentStreak = 1;
    let longestStreak = 1;
    let tempStreak = 1;

    for (let i = 1; i < dates.length; i++) {
        const prevDate = new Date(dates[i - 1]);
        const currDate = new Date(dates[i]);
        const diffDays = Math.floor((prevDate - currDate) / (1000 * 60 * 60 * 24));

        if (diffDays === 1) {
            tempStreak++;
            if (i === 1) currentStreak = tempStreak;
        } else {
            longestStreak = Math.max(longestStreak, tempStreak);
            tempStreak = 1;
        }
    }

    return {
        current: currentStreak,
        longest: Math.max(longestStreak, tempStreak)
    };
}
</script>
```

#### Step 4: Load Real Stats in Dashboard

Update `dashboard.html` line 454:

```javascript
async function loadStats() {
    const { data: { session } } = await client.auth.getSession();

    if (!session) return;

    // Fetch user stats
    const { data: stats, error } = await client
        .from('user_stats')
        .select('*')
        .eq('user_id', session.user.id)
        .single();

    if (error) {
        console.error('Error loading stats:', error);
        return;
    }

    if (stats) {
        // Update UI with real data
        document.getElementById('streak-count').textContent = stats.current_streak || 0;
        document.getElementById('completed-count').textContent = stats.topics_completed || 0;
        document.getElementById('points-count').textContent = stats.total_points || 0;

        // Calculate and show rank
        const rank = await getUserRank(session.user.id);
        document.getElementById('rank-value').textContent = rank ? `#${rank}` : '#-';
    } else {
        // No stats yet - create initial record
        await client
            .from('user_stats')
            .insert([{
                user_id: session.user.id,
                current_streak: 0,
                total_points: 0,
                topics_completed: 0
            }]);
    }

    // Load recent activity
    await loadRecentActivity(session.user.id);
}

async function getUserRank(userId) {
    // Get all users ordered by points
    const { data: users, error } = await client
        .from('user_stats')
        .select('user_id, total_points')
        .order('total_points', { ascending: false });

    if (error || !users) return null;

    // Find user's rank
    const rank = users.findIndex(u => u.user_id === userId) + 1;
    return rank || null;
}

async function loadRecentActivity(userId) {
    const { data: activities, error } = await client
        .from('user_activity')
        .select(`
            *,
            pages (title)
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(10);

    if (error || !activities || activities.length === 0) {
        return;
    }

    const container = document.getElementById('activity-list');
    container.innerHTML = '';

    activities.forEach(activity => {
        const activityEl = document.createElement('div');
        activityEl.className = 'activity-item';

        let title = '';
        if (activity.activity_type === 'page_complete') {
            title = `✅ Completed: ${activity.pages?.title || 'Unknown page'}`;
        } else if (activity.activity_type === 'page_view') {
            title = `👀 Viewed: ${activity.pages?.title || 'Unknown page'}`;
        }

        const timeAgo = getTimeAgo(activity.created_at);

        activityEl.innerHTML = `
            <div class="activity-title">${title}</div>
            <div class="activity-time">${timeAgo}</div>
        `;

        container.appendChild(activityEl);
    });
}

function getTimeAgo(timestamp) {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now - past;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    return past.toLocaleDateString();
}
```

---

## 🔒 Session Security

### Current Security Measures

1. **JWT Tokens** - Cryptographically signed
2. **Row Level Security (RLS)** - Users can only access their own data
3. **HTTPS Required** - Supabase enforces HTTPS
4. **Automatic Expiration** - Tokens expire and refresh

### Best Practices

**DO:**
- ✅ Always check session on protected pages
- ✅ Use RLS policies for database access
- ✅ Store only necessary data in user_metadata
- ✅ Handle session expiration gracefully

**DON'T:**
- ❌ Store sensitive data in localStorage (use database instead)
- ❌ Trust client-side data (always validate on server/database)
- ❌ Share session tokens
- ❌ Store passwords in any form

---

## 🧪 Testing Sessions

### Check Current Session (Browser Console)

```javascript
// Get Supabase client
const client = window.supabase.createClient(
    'YOUR_SUPABASE_URL',
    'YOUR_SUPABASE_ANON_KEY'
);

// Get current session
const { data: { session }, error } = await client.auth.getSession();

console.log('Session:', session);
console.log('User ID:', session?.user?.id);
console.log('Email:', session?.user?.email);
console.log('Name:', session?.user?.user_metadata?.full_name);
```

### Force Logout

```javascript
await client.auth.signOut();
// Session cleared, user will be redirected to login
```

### Check Session Expiry

```javascript
const { data: { session } } = await client.auth.getSession();

if (session) {
    const expiresAt = new Date(session.expires_at * 1000);
    console.log('Session expires at:', expiresAt);

    const now = new Date();
    const timeLeft = expiresAt - now;
    console.log('Time left:', Math.floor(timeLeft / 60000), 'minutes');
}
```

---

## 📋 Summary

### Current Implementation

- ✅ Sessions stored in browser localStorage
- ✅ Auto-refresh on token expiry
- ✅ Checked on every protected page load
- ✅ User data accessible via `session.user`
- ✅ Secure logout functionality

### Not Yet Implemented (Requires DB Tables)

- ❌ Activity tracking (page views, completions)
- ❌ Streak calculation
- ❌ Points system
- ❌ Real-time stats
- ❌ Leaderboard/rankings

### To Make Tracking Functional

1. Create database tables (SQL above)
2. Add "Mark as Complete" buttons to pages
3. Update dashboard.html to fetch real stats
4. Implement streak calculation logic
5. Add leaderboard page

---

**Your session management is solid! The tracking features just need database tables and UI updates to become functional.**

---

*Last updated: 2025-01-16*
*Version: 1.0 - Session Management Guide*
