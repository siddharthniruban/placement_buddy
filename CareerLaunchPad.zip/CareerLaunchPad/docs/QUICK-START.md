# ⚡ Quick Start Guide

Get your Career LaunchPad site up and running in 10 minutes!

## ✅ Pre-Launch Checklist

### Step 1: Database Setup (2 min)

1. **Run migration if needed:**
   ```sql
   -- In Supabase SQL Editor
   ALTER TABLE pages
   ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'other',
   ADD COLUMN IF NOT EXISTS difficulty TEXT;

   CREATE INDEX IF NOT EXISTS idx_pages_category ON pages(category);
   ```

2. **Verify RLS policies exist:**
   - Go to Authentication → Policies
   - Should see "Public pages are viewable by everyone"
   - Should see "Authenticated users can do everything"

### Step 2: Create Admin User (1 min)

1. **Supabase Dashboard**
   - Authentication → Users → Add User
   - Email: your-email@example.com
   - Password: [create strong password]
   - ✅ Click Create User

### Step 3: Test Locally (2 min)

```bash
# Start server
python -m http.server 8000

# Test authentication
# 1. Visit http://localhost:8000/login.html
# 2. Login with your credentials
# 3. Should redirect to admin panel
# 4. Try adding a test page

# Test filtering
# 1. Visit http://localhost:8000
# 2. Try the search bar
# 3. Click category filters
# 4. Verify pages appear correctly
```

### Step 4: Generate Sitemap (2 min)

```bash
# 1. Visit http://localhost:8000/generate-sitemap.html
# 2. Click "Generate Sitemap"
# 3. Click "Copy to Clipboard"
# 4. Create sitemap.xml in project root
# 5. Paste and save
```

### Step 5: Update for Production (1 min)

**In index.html**, find and replace (lines 17, 25, 31, 44, 63):

```
Old: https://careerlaunchpad.vercel.app/
New: https://your-actual-domain.vercel.app/
```

**In robots.txt** (line 6):
```
Old: Sitemap: https://careerlaunchpad.vercel.app/sitemap.xml
New: Sitemap: https://your-actual-domain.vercel.app/sitemap.xml
```

### Step 6: Deploy (1 min)

```bash
# If you have Vercel CLI
vercel --prod

# Or push to GitHub and deploy via Vercel dashboard
git add .
git commit -m "Add authentication and SEO"
git push origin main
```

### Step 7: Post-Deploy (1 min)

1. **Test production site:**
   - Visit your-domain.vercel.app
   - Try login
   - Add a page
   - Check it appears on homepage

2. **Verify SEO:**
   - Right-click → View Page Source
   - Look for `<meta property="og:title"`
   - Verify URLs are correct (not localhost)

---

## 🎯 Essential Post-Deploy Tasks

### Submit to Search Engines

**Google Search Console** (5 min)
1. Go to https://search.google.com/search-console
2. Add property: https://your-domain.vercel.app
3. Verify ownership (choose "URL prefix" method)
4. Sitemaps → Add sitemap: `sitemap.xml`
5. Done!

**Bing Webmaster Tools** (3 min)
1. Go to https://www.bing.com/webmasters
2. Add your site
3. Verify ownership
4. Submit sitemap
5. Done!

### Create Social Preview Images (Optional, 15 min)

1. Go to [Canva](https://canva.com)
2. Create 1200x630px design
3. Add your branding + tagline
4. Export as PNG
5. Upload to Supabase Storage
6. Update `og:image` URLs in index.html and page.html

### Set up Analytics (Optional, 5 min)

1. Create Google Analytics account
2. Get tracking ID
3. Add to index.html and page.html before `</head>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

---

## 🔥 First Content Tips

### Add Your First Pages

**Suggested starting content:**

1. **Welcome/Introduction**
   - Category: Interview
   - Difficulty: Easy
   - Brief overview of your platform

2. **Array Basics**
   - Category: Arrays
   - Difficulty: Easy
   - Fundamental array operations

3. **Interview Tips**
   - Category: Interview
   - Difficulty: Medium
   - Common interview advice

4. **Practice Problem**
   - Category: Arrays (or any)
   - Difficulty: Medium
   - Actual coding problem with solution

### Content Guidelines

✅ **DO:**
- Write clear, concise titles (3-6 words)
- Add descriptions (1-2 sentences)
- Use appropriate categories
- Set difficulty levels
- Include code examples
- Test interactive features

❌ **DON'T:**
- Use generic titles ("Page 1")
- Skip descriptions
- Mix categories randomly
- Forget to set Published = true
- Nest full HTML documents

---

## 🚨 Common Issues & Fixes

### "Can't login"
```
✅ Check user exists in Supabase → Authentication → Users
✅ Verify password is correct
✅ Clear browser localStorage and try again
✅ Check browser console for errors
```

### "Admin panel won't load"
```
✅ Check config.js has correct credentials
✅ Verify you're logged in (try /login.html)
✅ Check RLS policies allow authenticated access
✅ Look at browser console for errors
```

### "Search/filter not working"
```
✅ Hard refresh (Cmd+Shift+R or Ctrl+Shift+R)
✅ Verify pages have category field set
✅ Check browser console for JavaScript errors
✅ Verify you updated pages with categories
```

### "SEO tags not showing"
```
✅ Hard refresh page
✅ View page source (not inspector)
✅ Check that URLs don't have "localhost" in production
✅ Verify meta tags are in <head> section
```

### "Sitemap not generating"
```
✅ Check you have published pages
✅ Verify Supabase connection works
✅ Look at browser console for errors
✅ Try refreshing and clicking button again
```

---

## 📱 Mobile Testing

Before sharing with users, test on mobile:

1. **Chrome DevTools**
   - Press F12
   - Click device toolbar icon
   - Test iPhone/Android views

2. **Real Device**
   - Visit your URL on phone
   - Test search
   - Test filters
   - Try clicking cards
   - Verify content loads

3. **Mobile-Friendly Test**
   - https://search.google.com/test/mobile-friendly
   - Enter your URL
   - Fix any issues

---

## 🎨 Branding (Optional)

Make it yours! Update:

1. **Site Name**
   - index.html (line 18)
   - page.html (navbar)
   - admin.html (navbar)

2. **Colors**
   - styles.css (`:root` variables)
   - Change primary/secondary colors

3. **Favicon**
   - Create 32x32 icon
   - Add to `<head>`: `<link rel="icon" href="favicon.png">`

4. **Logo**
   - Replace 🚀 emoji in index.html
   - Or add `<img>` tag

---

## ✅ Launch Checklist

Before going live, verify:

- [ ] Database migration ran successfully
- [ ] Admin user created and tested
- [ ] Login/logout works correctly
- [ ] At least 3-5 pages added
- [ ] Categories assigned to all pages
- [ ] Search and filters work
- [ ] Sitemap.xml created
- [ ] Production URLs updated (no localhost)
- [ ] robots.txt has correct domain
- [ ] Deployed to Vercel successfully
- [ ] Tested on production URL
- [ ] Submitted sitemap to Google
- [ ] Mobile-friendly test passed
- [ ] Social preview tested (opengraph.xyz)

---

## 🎉 You're Ready!

Your site is now:
- ✅ **Secure** - Admin authentication enabled
- ✅ **SEO-optimized** - Ready for search engines
- ✅ **Production-ready** - Can handle real users
- ✅ **Scalable** - Supabase handles the backend

**Share your URL and start helping students learn!** 🚀

---

## 📚 Where to Go Next

**For Users:**
- Share on social media
- Submit to learning platforms
- Add to your resume/portfolio
- Get feedback and iterate

**For Development:**
- Read [SEO-GUIDE.md](./SEO-GUIDE.md) for ranking tips
- Check [SETUP-AUTH.md](./SETUP-AUTH.md) for advanced auth
- Review [README.md](./README.md) for full documentation
- Consider optional enhancements from IMPLEMENTATION-SUMMARY.md

**For Marketing:**
- Post on Twitter/LinkedIn
- Share in programming communities
- Write a blog post about your journey
- Submit to product directories

---

**Need help?**
- Check browser console
- Review Supabase logs
- Read the documentation
- Test in incognito mode

---

*Last updated: 2025-01-15*
*Estimated setup time: 10 minutes*
*Difficulty: Easy* ✅
