// Supabase Configuration
// Replace these with your actual Supabase credentials
const SUPABASE_URL = 'https://wdmubxrflznvwmmgjxxu.supabase.co'; // e.g., https://xxxxx.supabase.co
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndkbXVieHJmbHpudndtbWdqeHh1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU3ODc0MjMsImV4cCI6MjA4MTM2MzQyM30.tDfIkXQe_5M_czsWQx0GjEYz-dEm7uYc4GZaf5SKCHk';

// Initialize Supabase client (will be loaded from CDN)
let supabaseClient = null;

// Initialize the client when the page loads
function initSupabase() {
    if (typeof supabase === 'undefined') {
        console.error('Supabase library not loaded. Make sure to include it in your HTML.');
        return null;
    }

    supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    return supabaseClient;
}

// Table name for storing pages
const PAGES_TABLE = 'pages';
