# 🚀 Career LaunchPad

A modern, SEO-optimized learning platform for software engineers. Built with pure HTML/CSS/JavaScript and Supabase as a headless CMS.

## ✨ Features

### 🎯 Core Functionality
- **Dynamic Content Loading** - All content stored in Supabase, no redeployment needed
- **Category-based Organization** - Arrays, Linked Lists, Trees, Graphs, DP, Aptitude, Interview Tips
- **Smart Filtering & Search** - Real-time search and category filtering
- **Difficulty Badges** - Easy, Medium, Hard classifications
- **Interactive Content** - Support for JavaScript animations and visualizations

### 🔐 Security
- **Admin Authentication** - Supabase Auth protects admin panel
- **Protected Routes** - Admin and login pages secured
- **Session Management** - Persistent sessions with automatic logout

### 📈 SEO Optimized
- **Dynamic Meta Tags** - Title, description, keywords auto-generated
- **Open Graph Tags** - Rich previews on Facebook/LinkedIn
- **Twitter Cards** - Beautiful sharing on Twitter
- **Structured Data (JSON-LD)** - Schema.org markup for rich snippets
- **Sitemap Generation** - Automatic sitemap for search engines
- **Robots.txt** - Proper search engine directives

## 🗂️ Project Structure

```
CareerLaunchPad/
├── index.html              # Homepage with filters and search
├── page.html               # Dynamic page template (SEO optimized)
├── admin.html              # Content management panel (protected)
├── login.html              # Admin login page
├── styles.css              # Complete styling
├── script.js               # Homepage logic (filtering, search)
├── config.js               # Supabase configuration
├── robots.txt              # Search engine directives
├── generate-sitemap.html   # Sitemap generator utility
├── docs/                   # 📚 Documentation folder
│   ├── QUICK-START.md      # ⚡ 10-minute setup guide (START HERE!)
│   ├── SETUP-AUTH.md       # 🔐 Authentication setup guide
│   ├── SEO-GUIDE.md        # 📈 SEO implementation guide
│   ├── IMPLEMENTATION-SUMMARY.md  # 📋 Complete overview
│   ├── COMPLETE-SETUP.sql  # Full database setup with samples
│   └── supabase-migration.sql  # Schema updates
└── README.md               # This file
```

## 🎯 How It Works

1. **HTML pages stored in Supabase** - All page content lives in a Supabase database table
2. **Homepage fetches and displays pages** - Index page queries Supabase and generates thumbnails
3. **Dynamic page loader** - page.html loads content based on URL parameter
4. **Admin panel for management** - Add/edit/delete pages without touching code
5. **No redeployment needed** - Changes appear instantly

## 🛠️ Setup Instructions

### Step 1: Clone/Download the Project

```bash
git clone <your-repo-url>
cd CareerLaunchPad
```

### Step 2: Set Up Supabase

Follow the detailed guide in **[SUPABASE_SETUP.md](./SUPABASE_SETUP.md)**

Quick version:
1. Create a Supabase account at [supabase.com](https://supabase.com)
2. Create a new project
3. Run the SQL from SUPABASE_SETUP.md to create the pages table
4. Copy your project URL and anon key

### Step 3: Configure Your Project

Edit `config.js` and add your Supabase credentials:

```javascript
const SUPABASE_URL = 'https://your-project-id.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key-here';
```

### Step 4: Test Locally

```bash
# Using Python
python -m http.server 8000

# Using Node.js
npx serve

# Using PHP
php -S localhost:8000
```

Visit `http://localhost:8000`

### Step 5: Add Your First Page

1. Go to `http://localhost:8000/admin.html`
2. Fill in the form:
   - **Title:** About Us
   - **Slug:** about
   - **Icon:** 📄
   - **Description:** Learn more about us
   - **HTML Content:** (paste your HTML)
   - Click **Save Page**
3. Return to homepage - your page appears automatically!

### Step 6: Deploy to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Or push to GitHub and import in Vercel dashboard
```

## 📝 Adding Content

### Using the Admin Panel

1. Go to `/admin.html` on your deployed site
2. Fill in the form:
   - **Title** - Displayed on page card and as page heading
   - **Slug** - URL identifier (e.g., "about" → `/page.html?page=about`)
   - **Icon** - Single emoji for the card (e.g., 📄, 🛠️, ✍️)
   - **Description** - Brief text shown on the card
   - **HTML Content** - Full HTML content for the page
   - **Order** - Lower numbers appear first
   - **Published** - Toggle visibility

3. Click **Save Page**

### HTML Content Templates

**Basic Page:**
```html
<section class="page-hero">
    <div class="container">
        <h1>Page Title</h1>
        <p>Page subtitle or description</p>
    </div>
</section>

<section class="content-section">
    <div class="container">
        <div class="content-wrapper">
            <h2>Section Heading</h2>
            <p>Your content here...</p>
        </div>
    </div>
</section>
```

**With Feature Grid:**
```html
<section class="content-section">
    <div class="container">
        <h2>Our Features</h2>
        <div class="features-grid">
            <div class="feature-item">
                <h3>Feature 1</h3>
                <p>Description</p>
            </div>
            <div class="feature-item">
                <h3>Feature 2</h3>
                <p>Description</p>
            </div>
        </div>
    </div>
</section>
```

**With CTA:**
```html
<section class="content-section">
    <div class="container">
        <div class="cta-section">
            <h2>Ready to Get Started?</h2>
            <p>Join us today!</p>
            <a href="/#contact" class="cta-button">Contact Us</a>
        </div>
    </div>
</section>
```

See all available CSS classes in `styles.css`

## 🎨 Customization

### Change Brand Colors

Edit `styles.css`:

```css
:root {
    --primary-color: #2563eb;      /* Main brand color */
    --secondary-color: #1e40af;    /* Darker shade */
    --text-color: #1f2937;         /* Body text */
    --bg-color: #ffffff;           /* Background */
}
```

### Modify Homepage Sections

Edit `index.html` to customize:
- Hero section
- About section
- Resources section
- Contact form

### Add Custom Styling

All pages have access to `styles.css`. You can:
- Use existing classes
- Add custom classes to your HTML content
- Extend `styles.css` with new styles

## 📊 Database Schema

The `pages` table in Supabase:

| Field | Type | Description |
|-------|------|-------------|
| id | UUID | Auto-generated unique ID |
| title | TEXT | Page title |
| slug | TEXT | URL slug (unique) |
| icon | TEXT | Emoji icon |
| description | TEXT | Card description |
| html_content | TEXT | Full HTML content |
| order_index | INTEGER | Display order |
| published | BOOLEAN | Visibility flag |
| views | INTEGER | View counter |
| created_at | TIMESTAMP | Creation time |
| updated_at | TIMESTAMP | Last update |

## 🔐 Admin Authentication

### Login System
- ✅ **Secure authentication** using Supabase Auth
- ✅ **Protected admin panel** - Requires login to access
- ✅ **Session management** - Persistent login with logout functionality
- ✅ **Auto-redirect** - Unauthorized users sent to login page

### Setup
1. Create admin user in Supabase (Authentication → Users)
2. Login at `/login.html`
3. Access protected admin panel at `/admin.html`

📖 **Full guide:** [docs/SETUP-AUTH.md](./docs/SETUP-AUTH.md)

## 🚀 Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Import in Vercel dashboard
3. Vercel auto-detects as static site
4. Deploy!

**Environment Variables:**
- Not needed (credentials in config.js)
- For better security, use Vercel environment variables

### Other Platforms

Works on:
- Netlify
- GitHub Pages
- Any static host

Just ensure `config.js` has correct credentials.

## 📈 Benefits

**No Redeployment:**
- Add pages instantly via admin panel
- Changes appear immediately
- No git commits needed

**Lightweight:**
- No Node.js build process
- No React/Vue/Angular overhead
- Fast page loads
- Low bandwidth usage

**Easy Management:**
- Non-technical users can add content
- Visual admin interface
- Drag-and-drop HTML editing

**Scalable:**
- Supabase handles all data
- No database on your server
- Pages cached by CDN

## 🛟 Troubleshooting

**Pages not loading?**
- Check config.js has correct Supabase credentials
- Verify table was created (run SQL from SUPABASE_SETUP.md)
- Check browser console for errors

**Can't save pages in admin?**
- Verify Supabase RLS policies are set
- Check that all required fields are filled
- See browser console for error details

**Styling looks broken?**
- Ensure styles.css is loading
- Check that HTML uses correct class names
- Verify container divs are properly nested

## 📈 SEO & Marketing

### What's Included
- ✅ Dynamic meta tags per page
- ✅ Open Graph tags for social sharing
- ✅ Twitter Card support
- ✅ JSON-LD structured data
- ✅ Robots.txt for crawlers
- ✅ Sitemap generator included

### Next Steps
1. Generate sitemap at `/generate-sitemap.html`
2. Submit to Google Search Console
3. Create custom Open Graph images
4. Set up Google Analytics

📖 **Complete guide:** [docs/SEO-GUIDE.md](./docs/SEO-GUIDE.md)

## 📚 Documentation

All documentation is organized in the **[docs/](./docs/)** folder:

- **[docs/QUICK-START.md](./docs/QUICK-START.md)** ⚡ - 10-minute setup guide (START HERE!)
- **[docs/SETUP-AUTH.md](./docs/SETUP-AUTH.md)** 🔐 - Authentication setup and management
- **[docs/SEO-GUIDE.md](./docs/SEO-GUIDE.md)** 📈 - SEO optimization best practices
- **[docs/IMPLEMENTATION-SUMMARY.md](./docs/IMPLEMENTATION-SUMMARY.md)** 📋 - Complete implementation overview
- **[docs/COMPLETE-SETUP.sql](./docs/COMPLETE-SETUP.sql)** - Full database setup with sample content
- **[docs/supabase-migration.sql](./docs/supabase-migration.sql)** - Schema updates for existing databases

**External Resources:**
- [Supabase Documentation](https://supabase.com/docs)
- [Vercel Documentation](https://vercel.com/docs)

## 🤝 Contributing

Feel free to customize this template for your needs!

## 📄 License

MIT License - Use freely for any project

---

**Need help?** Check SUPABASE_SETUP.md or open an issue!
