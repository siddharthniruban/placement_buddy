# Supabase Setup Guide

This guide will help you set up Supabase to store and manage your HTML pages dynamically.

## Step 1: Create a Supabase Project

1. Go to [https://supabase.com](https://supabase.com)
2. Click "Start your project" and sign up (free tier available)
3. Create a new project:
   - Enter a project name (e.g., "career-launchpad")
   - Create a strong database password
   - Select a region closest to your users
   - Click "Create new project"

## Step 2: Create the Pages Table

1. In your Supabase dashboard, go to the **SQL Editor**
2. Click "New Query"
3. Copy and paste this SQL code:

```sql
-- Create pages table
CREATE TABLE pages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    icon TEXT DEFAULT '📄',
    description TEXT,
    html_content TEXT NOT NULL,
    order_index INTEGER DEFAULT 0,
    published BOOLEAN DEFAULT true,
    views INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on slug for faster lookups
CREATE INDEX idx_pages_slug ON pages(slug);

-- Create index on published and order_index for homepage queries
CREATE INDEX idx_pages_published_order ON pages(published, order_index);

-- Enable Row Level Security (RLS)
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public read access to published pages
CREATE POLICY "Allow public read access to published pages"
ON pages FOR SELECT
USING (published = true);

-- Create policy to allow all operations without authentication (for now)
-- WARNING: In production, you should restrict this to authenticated users only
CREATE POLICY "Allow all operations for development"
ON pages FOR ALL
USING (true)
WITH CHECK (true);

-- Create a function to increment view count
CREATE OR REPLACE FUNCTION increment_page_views(page_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE pages
    SET views = views + 1
    WHERE id = page_id;
END;
$$ LANGUAGE plpgsql;
```

4. Click **Run** to execute the SQL

## Step 3: Get Your Supabase Credentials

1. In your Supabase dashboard, go to **Settings** → **API**
2. Copy these two values:
   - **Project URL** (e.g., `https://xxxxx.supabase.co`)
   - **anon public** key (under "Project API keys")

## Step 4: Configure Your Project

1. Open `config.js` in your project
2. Replace the placeholder values:

```javascript
const SUPABASE_URL = 'https://your-project-id.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key-here';
```

## Step 5: Add Sample Content

1. Open `http://localhost:8000/admin.html` (or your deployed URL)
2. Fill in the form to add your first page:

**Example Page:**
- **Title:** About Us
- **Slug:** about
- **Icon:** 📄
- **Description:** Learn more about Career LaunchPad
- **HTML Content:**
```html
<section class="page-hero">
    <div class="container">
        <h1>About Us</h1>
        <p>Your career success partner</p>
    </div>
</section>
<section class="content-section">
    <div class="container">
        <h2>Our Mission</h2>
        <p>We help professionals achieve their career goals through expert guidance and resources.</p>
    </div>
</section>
```
- **Display Order:** 1
- **Published:** ✅ Checked

3. Click **Save Page**

## Step 6: View Your Page

1. Go to your homepage
2. You should see the page card appear automatically
3. Click on it to view the page at `/page.html?page=about`

## Database Schema

Here's what each field in the `pages` table does:

| Field | Type | Description |
|-------|------|-------------|
| `id` | UUID | Unique identifier (auto-generated) |
| `title` | TEXT | Page title shown on card |
| `slug` | TEXT | URL-friendly identifier (must be unique) |
| `icon` | TEXT | Emoji shown on card thumbnail |
| `description` | TEXT | Short description on card |
| `html_content` | TEXT | Full HTML content of the page |
| `order_index` | INTEGER | Sort order (lower = first) |
| `published` | BOOLEAN | Whether page is visible to users |
| `views` | INTEGER | Page view counter |
| `created_at` | TIMESTAMP | When page was created |
| `updated_at` | TIMESTAMP | Last update time |

## Security Considerations

### For Development (Current Setup)
The current setup allows anyone to create/edit/delete pages. This is fine for development.

### For Production
You should implement authentication:

1. **Enable Supabase Auth:**
   ```sql
   -- Remove the permissive policy
   DROP POLICY "Allow all operations for development" ON pages;

   -- Create admin-only policy
   CREATE POLICY "Allow authenticated admin users to manage pages"
   ON pages FOR ALL
   USING (auth.uid() IN (
       SELECT user_id FROM admin_users
   ))
   WITH CHECK (auth.uid() IN (
       SELECT user_id FROM admin_users
   ));
   ```

2. **Add authentication to admin.html:**
   - Use Supabase Auth UI
   - Restrict admin page access to authenticated users
   - Add user role management

## Tips for Adding Content

### HTML Content Best Practices

1. **Use the page-hero section for headers:**
```html
<section class="page-hero">
    <div class="container">
        <h1>Page Title</h1>
        <p>Subtitle or description</p>
    </div>
</section>
```

2. **Use content-section for body content:**
```html
<section class="content-section">
    <div class="container">
        <h2>Section Title</h2>
        <p>Your content here...</p>
    </div>
</section>
```

3. **Available CSS classes:**
   - `.content-wrapper` - Max-width content container
   - `.features-grid` - Grid layout for feature cards
   - `.cta-section` - Call-to-action section
   - `.blog-grid` - Grid for blog posts
   - `.testimonials-grid` - Grid for testimonials
   - All classes from `styles.css` are available

### Emoji Icons
Use single emojis for best display:
- 📄 Document
- 🛠️ Tools
- ✍️ Writing
- 💼 Business
- 💰 Pricing
- 🎓 Education
- 📧 Contact
- 🚀 Launch

## Troubleshooting

### Pages not loading?
1. Check browser console for errors
2. Verify config.js has correct credentials
3. Check Supabase dashboard for table existence
4. Ensure RLS policies are set correctly

### Can't save pages in admin?
1. Check that the policy allows inserts
2. Verify all required fields are filled
3. Check browser console for detailed error

### Pages appear but content doesn't load?
1. Verify the page is marked as published
2. Check the slug matches exactly
3. Ensure HTML content is valid

## Next Steps

- Add authentication to admin panel
- Implement image uploads via Supabase Storage
- Add SEO metadata fields
- Create page categories/tags
- Add search functionality
- Implement page analytics

## Support

If you encounter issues:
1. Check [Supabase Documentation](https://supabase.com/docs)
2. Review browser console errors
3. Check Supabase logs in dashboard
