// Enhanced script with filtering and search

let allPages = [];
let currentCategory = 'all';
let searchQuery = '';

// Initialize Supabase and load pages
document.addEventListener('DOMContentLoaded', async () => {
    const client = initSupabase();
    const pagesGrid = document.getElementById('pages-grid');

    if (pagesGrid && client) {
        await loadPagesFromSupabase(client);
        setupFilters();
        setupSearch();
    }
});

// Load pages from Supabase
async function loadPagesFromSupabase(client) {
    const pagesGrid = document.getElementById('pages-grid');

    try {
        const { data: pages, error } = await client
            .from(PAGES_TABLE)
            .select('*')
            .eq('published', true)
            .order('order_index', { ascending: true });

        if (error) throw error;

        pagesGrid.innerHTML = '';

        if (!pages || pages.length === 0) {
            pagesGrid.innerHTML = `
                <div class="no-pages-message">
                    <p>No resources available yet. Add some content in the <a href="/admin.html">Admin Panel</a>!</p>
                </div>
            `;
            return;
        }

        allPages = pages;
        renderPages(pages);
        updateCategoryCounts();

    } catch (error) {
        console.error('Error loading pages:', error);
        pagesGrid.innerHTML = `
            <div class="error-message">
                <p>Failed to load resources. Please check your Supabase configuration.</p>
            </div>
        `;
    }
}

// Render pages
function renderPages(pages) {
    const pagesGrid = document.getElementById('pages-grid');
    pagesGrid.innerHTML = '';

    if (pages.length === 0) {
        document.getElementById('no-results').style.display = 'block';
        return;
    }

    document.getElementById('no-results').style.display = 'none';

    pages.forEach(page => {
        const card = createEnhancedPageCard(page);
        pagesGrid.appendChild(card);
    });

    document.getElementById('showing-count').textContent =
        `Showing ${pages.length} of ${allPages.length} resources`;

    applyScrollAnimations();
}

// Create enhanced page card
function createEnhancedPageCard(page) {
    const card = document.createElement('a');
    card.href = `page.html?page=${page.slug}`;
    card.className = 'page-card';
    card.dataset.category = page.category || 'other';
    card.dataset.difficulty = page.difficulty || '';
    card.dataset.title = page.title.toLowerCase();
    card.dataset.description = (page.description || '').toLowerCase();

    // Determine difficulty tag
    let difficultyTag = '';
    if (page.difficulty) {
        difficultyTag = `<span class="tag difficulty-${page.difficulty.toLowerCase()}">${page.difficulty}</span>`;
    }

    // Category tag
    let categoryTag = '';
    if (page.category) {
        categoryTag = `<span class="tag category">${formatCategory(page.category)}</span>`;
    }

    card.innerHTML = `
        <div class="card-header">
            <div class="card-title-row">
                <span class="card-icon">${page.icon || '📄'}</span>
                <h3 class="card-title">${page.title}</h3>
            </div>
            <div class="card-tags">
                ${difficultyTag}
                ${categoryTag}
            </div>
        </div>
        <div class="card-body">
            <p class="card-description">${page.description || 'Click to explore'}</p>
            <div class="card-meta">
                <span class="meta-item">👁️ ${page.views || 0} views</span>
            </div>
        </div>
    `;

    return card;
}

// Format category name
function formatCategory(category) {
    const categoryNames = {
        'array': 'Arrays',
        'linked-list': 'Linked Lists',
        'tree': 'Trees',
        'graph': 'Graphs',
        'dp': 'DP',
        'aptitude': 'Aptitude',
        'interview': 'Interview',
        'other': 'Other'
    };
    return categoryNames[category] || category;
}

// Setup category filters
function setupFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active state
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Get category
            currentCategory = btn.dataset.category;

            // Filter and render
            filterAndRender();
        });
    });
}

// Setup search
function setupSearch() {
    const searchInput = document.getElementById('search-input');

    searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase();
        filterAndRender();
    });
}

// Filter and render pages
function filterAndRender() {
    let filtered = allPages;

    // Filter by category
    if (currentCategory !== 'all') {
        filtered = filtered.filter(page =>
            (page.category || 'other') === currentCategory
        );
    }

    // Filter by search
    if (searchQuery) {
        filtered = filtered.filter(page => {
            const title = page.title.toLowerCase();
            const description = (page.description || '').toLowerCase();
            const category = (page.category || '').toLowerCase();

            return title.includes(searchQuery) ||
                   description.includes(searchQuery) ||
                   category.includes(searchQuery);
        });
    }

    renderPages(filtered);
}

// Update category counts
function updateCategoryCounts() {
    const categories = ['all', 'array', 'linked-list', 'tree', 'graph', 'dp', 'aptitude', 'interview'];

    categories.forEach(cat => {
        const count = cat === 'all'
            ? allPages.length
            : allPages.filter(p => (p.category || 'other') === cat).length;

        const countEl = document.getElementById(`count-${cat}`);
        if (countEl) {
            countEl.textContent = count;
        }
    });
}

// Reset filters
function resetFilters() {
    currentCategory = 'all';
    searchQuery = '';
    document.getElementById('search-input').value = '';
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.category === 'all') {
            btn.classList.add('active');
        }
    });
    filterAndRender();
}

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// Animation observer
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

function applyScrollAnimations() {
    document.querySelectorAll('.page-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        observer.observe(card);
    });
}
